@echo off
setlocal EnableDelayedExpansion
set "ROOT=%~dp0"
if "%ROOT:~-1%"=="\" set "ROOT=%ROOT:~0,-1%"
cd /d "%ROOT%"
chcp 65001 >nul 2>&1
title Lobster Online Client

set "CLIENT_PORT=8000"
set "API_BASE=http://47.120.39.220:8000"
if exist ".env" (
    for /f "usebackq eol=# tokens=1,* delims==" %%a in (".env") do (
        if "%%a"=="ONLINE_CLIENT_PORT" for /f "tokens=* delims= " %%e in ("%%b") do set "CLIENT_PORT=%%e"
        if "%%a"=="ONLINE_API_BASE" for /f "tokens=* delims= " %%e in ("%%b") do set "API_BASE=%%e"
    )
)

REM Prefer 完整包内置嵌入式 Python（与 install.bat / start.bat 一致），再尝试系统 PATH
set "PYTHON="
if exist "python\python.exe" (
    set "PYTHON=%CD%\python\python.exe"
    goto :python_ok
)
where python >nul 2>&1
if not errorlevel 1 (
    set "PYTHON=python"
    goto :python_ok
)
where python3 >nul 2>&1
if not errorlevel 1 (
    set "PYTHON=python3"
    goto :python_ok
)
echo [ERR] Python not found. Run install.bat first, or install Python 3.10+ and ensure ^"python^" is on PATH.
pause
exit /b 1

:python_ok
"%PYTHON%" -c "print(1)" >nul 2>&1
if errorlevel 1 (
    echo [ERR] Python at "%PYTHON%" failed to run. Re-run install.bat or fix your Python install.
    pause
    exit /b 1
)

echo ================================================
echo   Lobster Online Client
echo ================================================
echo   URL:  http://127.0.0.1:%CLIENT_PORT%/?api=!API_BASE!
echo   API:  !API_BASE!
echo ================================================
echo.
echo [Code] checking client code pack update...
"%PYTHON%" "%ROOT%\scripts\check_client_code_update.py"
echo.
echo   Opening browser...
start "" "http://127.0.0.1:%CLIENT_PORT%/?api=!API_BASE!"
echo   Starting static server (Ctrl+C to stop)...
echo.
"%PYTHON%" scripts\serve_online_client.py %CLIENT_PORT% "!API_BASE!"
pause

