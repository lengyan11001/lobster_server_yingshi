#!/usr/bin/env bash
# 完整包 / 离线安装：保证 deps/wheels 覆盖 requirements.txt + get-pip.py
# - 先 ensure_pack_deps（pycryptodome + tos）
# - 若 verify 已通过 → 跳过联网下载（已有完整 wheel）
# - 若未通过 → 执行 prepare_offline.py（需联网）；失败即退出
# - 设 FORCE_PREPARE_OFFLINE=1 可强制重新执行 prepare_offline.py
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
echo "==> [full-offline] 1/3 ensure_pack_deps.sh（pycryptodome win + tos）"
bash scripts/ensure_pack_deps.sh

if [ "${FORCE_PREPARE_OFFLINE:-}" = "1" ]; then
  echo "==> [full-offline] FORCE_PREPARE_OFFLINE=1 → prepare_offline.py"
  python3 scripts/prepare_offline.py --target windows
elif python3 scripts/verify_offline_wheels.py 2>/dev/null; then
  echo "==> [full-offline] 2/3 deps/wheels 已满足 requirements，跳过 prepare_offline（需强制重下请设 FORCE_PREPARE_OFFLINE=1）"
else
  echo "==> [full-offline] 2/3 prepare_offline.py（补齐 wheel，需联网）"
  python3 scripts/prepare_offline.py --target windows
fi

echo "==> [full-offline] 3/3 verify_offline_wheels.py"
python3 scripts/verify_offline_wheels.py
echo "==> [full-offline] 校验通过"

# Windows 素材剪辑：仅当本地尚无 ffmpeg.exe 时才下载（INCLUDE_FFMPEG=1）
if [ "${INCLUDE_FFMPEG:-}" = "1" ]; then
  if [ -f "deps/ffmpeg/ffmpeg.exe" ]; then
    echo "==> [ffmpeg] deps/ffmpeg/ffmpeg.exe 已存在，跳过下载"
  else
    echo "==> [ffmpeg] 缺少 ffmpeg.exe → ensure_ffmpeg_windows.py（需联网）"
    python3 scripts/ensure_ffmpeg_windows.py
  fi
fi
