#!/usr/bin/env python3
"""
打「纯代码」OTA zip（与 scripts/check_client_code_update.py 的 DEFAULT_PATHS 一致）。
不含 python/、deps/、browser_chromium/、nodejs 可执行文件；openclaw 不含 workspace*/logs/.env。
"""
from __future__ import annotations

import argparse
import hashlib
import os
import zipfile
from pathlib import Path

# 与 check_client_code_update.DEFAULT_PATHS 保持一致
OTA_PATHS: tuple[str, ...] = (
    "backend",
    "mcp",
    "static",
    "scripts",
    "publisher",
    "skills",
    "skill_registry.json",
    "upstream_urls.json",
    "openclaw",
    "requirements.txt",
    ".env.example",
    "install.bat",
    "start.bat",
    "start_online.bat",
    "start_headless.bat",
    "run_backend.bat",
    "run_mcp.bat",
    "nodejs/package.json",
    "nodejs/package-lock.json",
)

SKIP_DIR_NAMES = {"__pycache__", ".git"}

# 本地调试/抓页面临时目录，非交付代码（曾占 OTA 包约 16MB+）
OTA_SKIP_REL_PREFIXES: tuple[str, ...] = ("scripts/_probe",)


def _norm(p: str) -> str:
    return p.replace("\\", "/")


def _skip_file(rel: str) -> bool:
    r = _norm(rel).lower()
    if r.endswith(".pyc"):
        return True
    parts = r.split("/")
    if "__pycache__" in parts:
        return True
    nr = _norm(rel)
    if any(nr.startswith(p) for p in OTA_SKIP_REL_PREFIXES):
        return True
    return False


def _add_tree(zf: zipfile.ZipFile, root: Path, rel_dir: str) -> None:
    base = root / rel_dir.replace("/", os.sep)
    if not base.exists():
        return
    if base.is_file():
        if _skip_file(rel_dir):
            return
        zf.write(base, rel_dir)
        return
    for dirpath, dirnames, filenames in os.walk(base):
        rel_here = _norm(os.path.relpath(dirpath, str(root)))
        dirnames[:] = [
            d
            for d in dirnames
            if d not in SKIP_DIR_NAMES
            and not any(_norm(os.path.join(rel_here, d)).startswith(p) for p in OTA_SKIP_REL_PREFIXES)
        ]
        for name in filenames:
            full = Path(dirpath) / name
            rel = _norm(os.path.relpath(str(full), str(root)))
            if _skip_file(rel):
                continue
            zf.write(full, rel)


def _add_openclaw(zf: zipfile.ZipFile, root: Path) -> None:
    base = root / "openclaw"
    if not base.is_dir():
        return
    for dirpath, dirnames, filenames in os.walk(base):
        dirnames[:] = [
            d
            for d in dirnames
            if d not in SKIP_DIR_NAMES
            and d != "workspace"
            and not d.startswith("workspace-")
            and d != "logs"
        ]
        for name in filenames:
            if name == ".env" or name.endswith(".bak") or ".bak." in name:
                continue
            full = Path(dirpath) / name
            rel = _norm(os.path.relpath(str(full), str(root)))
            if _skip_file(rel):
                continue
            zf.write(full, rel)


def main() -> int:
    ap = argparse.ArgumentParser(description="Pack client-code OTA zip")
    ap.add_argument(
        "--root",
        type=Path,
        default=Path(__file__).resolve().parent.parent,
        help="lobster_online 根目录",
    )
    ap.add_argument("--out", type=Path, required=True, help="输出 .zip 路径")
    args = ap.parse_args()
    root: Path = args.root.resolve()
    out: Path = args.out.resolve()
    if not root.is_dir():
        print(f"[ERR] root 不是目录: {root}")
        return 1
    out.parent.mkdir(parents=True, exist_ok=True)
    if out.exists():
        out.unlink()

    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for p in OTA_PATHS:
            rel = p.replace("\\", "/")
            src = root / rel.replace("/", os.sep)
            if not src.exists():
                print(f"[WARN] 缺失，跳过: {rel}")
                continue
            if rel == "openclaw":
                _add_openclaw(zf, root)
            else:
                _add_tree(zf, root, rel)

    h = hashlib.sha256()
    with out.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    digest = h.hexdigest()
    print(out)
    print(f"sha256={digest}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
