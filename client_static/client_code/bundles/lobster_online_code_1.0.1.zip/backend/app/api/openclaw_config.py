"""OpenClaw Gateway configuration: status check, API key management, model selection, restart."""
import json
import logging
import os
import platform
import re
import subprocess
import threading
import time
from pathlib import Path
from typing import Optional

import httpx
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel

from ..core.config import settings
from .auth import get_current_user_for_local, _ServerUser

logger = logging.getLogger(__name__)

# 清除本机 Key / 保存配置 / 手动重启 可能并发触发重启；串行化避免重复 Popen 出多个 node
_OPENCLAW_RESTART_LOCK = threading.Lock()

router = APIRouter()

_BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
_OC_DIR = _BASE_DIR / "openclaw"
_OC_CONFIG = _OC_DIR / "openclaw.json"
_OC_ENV = _OC_DIR / ".env"

SUPPORTED_PROVIDERS = [
    {"id": "anthropic", "name": "Anthropic", "env_key": "ANTHROPIC_API_KEY",
     "models": ["anthropic/claude-sonnet-4-5", "anthropic/claude-opus-4-6", "anthropic/claude-haiku-3-5"]},
    {"id": "openai", "name": "OpenAI", "env_key": "OPENAI_API_KEY",
     "models": ["openai/gpt-4o", "openai/gpt-4o-mini", "openai/o3-mini"]},
    {"id": "deepseek", "name": "DeepSeek", "env_key": "DEEPSEEK_API_KEY",
     "models": ["deepseek/deepseek-chat", "deepseek/deepseek-reasoner"]},
    {"id": "google", "name": "Google", "env_key": "GEMINI_API_KEY",
     "models": ["google/gemini-2.5-pro", "google/gemini-2.5-flash"]},
]

DEEPSEEK_PROVIDER_TEMPLATE = {
    "baseUrl": "https://api.deepseek.com",
    "api": "openai-completions",
    "models": [
        {"id": "deepseek-chat", "name": "DeepSeek Chat", "input": ["text"],
         "contextWindow": 65536, "maxTokens": 8192},
        {"id": "deepseek-reasoner", "name": "DeepSeek Reasoner", "reasoning": True,
         "input": ["text"], "contextWindow": 65536, "maxTokens": 8192},
    ],
}


def _mask_key(key: str) -> str:
    if not key or len(key) < 8:
        return ""
    return key[:4] + "*" * (len(key) - 8) + key[-4:]


def _read_oc_env() -> dict[str, str]:
    result: dict[str, str] = {}
    if not _OC_ENV.exists():
        return result
    for line in _OC_ENV.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" in line:
            k, _, v = line.partition("=")
            result[k.strip()] = v.strip()
    return result


def _write_oc_env(data: dict[str, str]):
    _OC_DIR.mkdir(parents=True, exist_ok=True)
    lines = []
    lines.append("# OpenClaw LLM API Keys")
    lines.append("# 在龙虾后台设置后自动写入")
    for k, v in sorted(data.items()):
        lines.append(f"{k}={v}")
    _OC_ENV.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _read_oc_config() -> dict:
    if not _OC_CONFIG.exists():
        return {}
    try:
        return json.loads(_OC_CONFIG.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _write_oc_config(config: dict):
    _OC_DIR.mkdir(parents=True, exist_ok=True)
    _OC_CONFIG.write_text(json.dumps(config, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def _model_to_agent_id(model: str) -> str:
    """Slugify a model ID into an OpenClaw agent ID."""
    slug = model.lower().replace("/", "-").replace(".", "-")
    slug = re.sub(r'[^a-z0-9_-]', '-', slug)
    slug = re.sub(r'-+', '-', slug).strip('-')
    return slug[:64] or "main"


def _build_agents_list(primary_model: str) -> list[dict]:
    """Build the agents.list array from SUPPORTED_PROVIDERS.

    The default agent ('main') uses the primary model.
    Every supported model also gets a dedicated agent so switching the primary
    later never leaves a model without an agent entry.
    """
    agents = [{"id": "main", "default": True}]
    seen: set[str] = set()
    for prov in SUPPORTED_PROVIDERS:
        for model_id in prov["models"]:
            if model_id in seen:
                continue
            seen.add(model_id)
            agents.append({"id": _model_to_agent_id(model_id), "model": model_id})
    return agents


def _ensure_provider_configs(config: dict):
    """Dynamically add/remove non-built-in providers based on actual API key values.

    Uses the real key value in openclaw.json (not ${ENV_VAR} templates) to avoid
    OpenClaw SecretRef startup failures when keys are empty.
    """
    env_data = _read_oc_env()
    providers = config.setdefault("models", {}).setdefault("providers", {})

    ds_key = env_data.get("DEEPSEEK_API_KEY", "").strip()
    if ds_key:
        ds_cfg = dict(DEEPSEEK_PROVIDER_TEMPLATE)
        ds_cfg["apiKey"] = ds_key
        providers["deepseek"] = ds_cfg
    else:
        providers.pop("deepseek", None)

    if not providers:
        config.get("models", {}).pop("providers", None)
        if not config.get("models"):
            config.pop("models", None)


def _ensure_agents_list(config: dict):
    """Ensure agents.list contains an agent for every supported model."""
    agents_node = config.setdefault("agents", {})
    primary = agents_node.get("defaults", {}).get("model", {}).get("primary", _DEFAULT_PRIMARY)
    agents_node["list"] = _build_agents_list(primary)


_DEFAULT_PRIMARY = "anthropic/claude-sonnet-4-5"


@router.get("/api/openclaw/status", summary="OpenClaw Gateway 状态")
async def openclaw_status(current_user: _ServerUser = Depends(get_current_user_for_local)):
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            r = await client.get("http://127.0.0.1:18789/")
        return {"online": True, "status_code": r.status_code}
    except Exception:
        return {"online": False, "status_code": None}


@router.get("/api/openclaw/config", summary="读取 OpenClaw 配置")
def get_openclaw_config(current_user: _ServerUser = Depends(get_current_user_for_local)):
    env_data = _read_oc_env()
    config = _read_oc_config()

    primary_model = ""
    try:
        primary_model = (
            config.get("agents", {}).get("defaults", {}).get("model", {}).get("primary", "")
            or config.get("agent", {}).get("model", {}).get("primary", "")
        )
    except Exception:
        pass

    providers_status = []
    for p in SUPPORTED_PROVIDERS:
        raw_key = env_data.get(p["env_key"], "")
        providers_status.append({
            "id": p["id"],
            "name": p["name"],
            "env_key": p["env_key"],
            "configured": bool(raw_key),
            "masked_key": _mask_key(raw_key),
            "models": p["models"],
        })

    return {
        "primary_model": primary_model,
        "providers": providers_status,
    }


class UpdateOpenClawConfig(BaseModel):
    primary_model: Optional[str] = None
    anthropic_api_key: Optional[str] = None
    openai_api_key: Optional[str] = None
    deepseek_api_key: Optional[str] = None
    gemini_api_key: Optional[str] = None


@router.post("/api/openclaw/config", summary="更新 OpenClaw 配置（本地）")
def update_openclaw_config(
    body: UpdateOpenClawConfig,
    current_user: _ServerUser = Depends(get_current_user_for_local),
):
    env_data = _read_oc_env()
    changed_keys = False

    key_map = {
        "ANTHROPIC_API_KEY": body.anthropic_api_key,
        "OPENAI_API_KEY": body.openai_api_key,
        "DEEPSEEK_API_KEY": body.deepseek_api_key,
        "GEMINI_API_KEY": body.gemini_api_key,
    }
    for env_key, value in key_map.items():
        if value is not None:
            env_data[env_key] = value.strip()
            changed_keys = True

    if changed_keys:
        _write_oc_env(env_data)

    config = _read_oc_config()

    if body.primary_model is not None:
        config.setdefault("agents", {}).setdefault("defaults", {}).setdefault("model", {})["primary"] = body.primary_model.strip()

    _ensure_provider_configs(config)
    _ensure_agents_list(config)
    _write_oc_config(config)

    restarted = False
    if changed_keys:
        restarted = _restart_openclaw_gateway()

    msg = "配置已保存"
    if restarted:
        msg += "，OpenClaw Gateway 已自动重启。"
    elif changed_keys:
        msg += "。API Key 已更新，但自动重启失败，请手动重启（stop.bat + start.bat）。"
    else:
        msg += "。"

    return {"ok": True, "message": msg, "restarted": restarted}


def _find_listener_pids_on_18789() -> list[int]:
    """在 18789 上 **LISTEN** 的进程 PID（不含连到该端口的客户端）。可能多个（异常残留时）。"""
    try:
        if platform.system() == "Windows":
            out = subprocess.check_output(
                'netstat -ano | findstr ":18789 " | findstr "LISTENING"',
                shell=True, text=True, stderr=subprocess.DEVNULL,
            )
            pids: set[int] = set()
            for line in out.strip().splitlines():
                parts = line.split()
                if parts:
                    try:
                        pids.add(int(parts[-1]))
                    except ValueError:
                        continue
            return sorted(pids)
        try:
            out = subprocess.check_output(
                ["lsof", "-nP", "-iTCP:18789", "-sTCP:LISTEN", "-t"],
                text=True,
                stderr=subprocess.DEVNULL,
            )
        except subprocess.CalledProcessError:
            return []
        lines = [x.strip() for x in out.strip().splitlines() if x.strip().isdigit()]
        return sorted({int(x) for x in lines})
    except Exception:
        return []


def _find_openclaw_pid() -> Optional[int]:
    """兼容：返回 18789 上第一个监听 PID（若无则 None）。"""
    pids = _find_listener_pids_on_18789()
    return pids[0] if pids else None


def _wait_until_no_listener_on_18789(max_wait: float = 6.0) -> None:
    """杀掉进程后端口可能短暂未释放，轮询直到无 LISTEN 或超时。"""
    deadline = time.time() + max_wait
    while time.time() < deadline:
        if not _find_listener_pids_on_18789():
            return
        time.sleep(0.12)


def _kill_pid(pid: int):
    try:
        if platform.system() == "Windows":
            subprocess.run(["taskkill", "/F", "/PID", str(pid)],
                           capture_output=True, timeout=10)
        else:
            os.kill(pid, 9)
    except Exception as e:
        logger.warning("Failed to kill PID %s: %s", pid, e)


def _build_openclaw_env() -> dict:
    """Build environment variables for the OpenClaw child process."""
    env = dict(os.environ)
    oc_env = _read_oc_env()
    env.update(oc_env)
    env["OPENCLAW_CONFIG_PATH"] = str(_OC_CONFIG)
    env["OPENCLAW_STATE_DIR"] = str(_OC_DIR)
    return env


def _find_openclaw_entry() -> Optional[tuple]:
    """Find node executable and openclaw.mjs path. Returns (node_path, mjs_path) or None."""
    import shutil

    base = _BASE_DIR

    mjs_candidates = [
        base / "nodejs" / "node_modules" / "openclaw" / "openclaw.mjs",
        base / "node_modules" / "openclaw" / "openclaw.mjs",
    ]
    mjs_path = None
    for p in mjs_candidates:
        if p.exists():
            mjs_path = str(p)
            break

    node_path = None
    if platform.system() == "Windows":
        for p in (base / "nodejs" / "node.exe", base / "nodejs" / "node"):
            if p.exists():
                node_path = str(p)
                break
        if not node_path:
            node_path = shutil.which("node")
    else:
        # macOS/Linux：包内 node.exe 常为 Windows PE，不可执行；勿选用。
        bundled = base / "nodejs" / "node"
        if bundled.exists() and os.access(bundled, os.X_OK):
            node_path = str(bundled)
        if not node_path:
            node_path = shutil.which("node")

    if node_path and mjs_path:
        return (node_path, mjs_path)
    return None


def _restart_openclaw_gateway_impl() -> bool:
    """在已持有 _OPENCLAW_RESTART_LOCK 时调用：杀光监听 PID，等端口释放，再启动唯一 Gateway。"""
    for pid in _find_listener_pids_on_18789():
        logger.info("Killing OpenClaw listener PID %s", pid)
        _kill_pid(pid)
    _wait_until_no_listener_on_18789(6.0)
    leftover = _find_listener_pids_on_18789()
    if leftover:
        logger.warning("Port 18789 still has listener PIDs after kill: %s — retrying SIGKILL", leftover)
        for pid in leftover:
            _kill_pid(pid)
        _wait_until_no_listener_on_18789(4.0)

    entry = _find_openclaw_entry()
    if not entry:
        logger.warning("Cannot restart OpenClaw: node or openclaw.mjs not found")
        return False

    node_path, mjs_path = entry
    env = _build_openclaw_env()
    log_path = _BASE_DIR / "openclaw.log"

    try:
        cmd = [node_path, mjs_path, "gateway", "--port", "18789"]
        log_file = None
        for _ in range(2):
            try:
                log_file = open(log_path, "a", encoding="utf-8")
                break
            except OSError as e:
                if getattr(e, "errno", None) == 13:  # Permission denied (file locked by previous process)
                    time.sleep(0.5)
                    continue
                raise
        if log_file is None:
            logger.warning("openclaw.log locked, OpenClaw stdout/stderr will not be written to file")
            log_file = subprocess.DEVNULL

        kwargs = {
            "stdout": log_file,
            "stderr": log_file,
            "env": env,
            "cwd": str(_BASE_DIR),
        }
        if platform.system() == "Windows":
            kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW

        subprocess.Popen(cmd, **kwargs)
        logger.info("OpenClaw Gateway restarting: %s", " ".join(cmd))
        time.sleep(2)

        new_pid = _find_openclaw_pid()
        if new_pid:
            logger.info("OpenClaw Gateway restarted, PID %s", new_pid)
            return True
        else:
            logger.warning("OpenClaw Gateway process started but not listening yet")
            return True
    except Exception as e:
        logger.error("Failed to restart OpenClaw Gateway: %s", e)
        return False


def _restart_openclaw_gateway() -> bool:
    """串行重启，避免「清除配置」与「保存 Key」等并发各拉起一个 node。"""
    with _OPENCLAW_RESTART_LOCK:
        return _restart_openclaw_gateway_impl()


@router.post("/api/openclaw/restart", summary="重启 OpenClaw Gateway")
async def restart_openclaw(current_user: _ServerUser = Depends(get_current_user_for_local)):
    ok = _restart_openclaw_gateway()
    if ok:
        return {"ok": True, "message": "OpenClaw Gateway 已重启"}
    return {"ok": False, "message": "重启失败，请手动执行 stop.bat + start.bat"}


def clear_openclaw_local_provider_keys() -> tuple[bool, bool]:
    """从本机 openclaw/.env 移除各厂商 API Key（仅写本地文件，不上传任何服务端）。

    Returns:
        (env_changed, gateway_restarted)
    """
    env_data = _read_oc_env()
    changed = False
    for k in ("ANTHROPIC_API_KEY", "OPENAI_API_KEY", "DEEPSEEK_API_KEY", "GEMINI_API_KEY"):
        if k in env_data and (env_data[k] or "").strip():
            del env_data[k]
            changed = True
    if not changed:
        return False, False
    _write_oc_env(env_data)
    restarted = _restart_openclaw_gateway()
    return True, restarted


# --------------- SuTui MCP Config ---------------

_SUTUI_CONFIG_PATH = _BASE_DIR / "sutui_config.json"
_UPSTREAM_URLS_PATH = _BASE_DIR / "upstream_urls.json"
_SUTUI_DEFAULT_URL = "https://api.xskill.ai/api/v3/mcp-http"


def _read_sutui_config() -> dict:
    if not _SUTUI_CONFIG_PATH.exists():
        return {}
    try:
        return json.loads(_SUTUI_CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _write_sutui_config(data: dict):
    _SUTUI_CONFIG_PATH.write_text(
        json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )


def _read_upstream_urls() -> dict:
    if not _UPSTREAM_URLS_PATH.exists():
        return {}
    try:
        return json.loads(_UPSTREAM_URLS_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _write_upstream_urls(data: dict):
    _UPSTREAM_URLS_PATH.write_text(
        json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )


@router.get("/api/sutui/config", summary="读取速推配置")
def get_sutui_config(current_user: _ServerUser = Depends(get_current_user_for_local)):
    from ..core.config import settings
    edition = (getattr(settings, "lobster_edition", None) or "online").strip().lower()
    urls = _read_upstream_urls()
    url = urls.get("sutui", _SUTUI_DEFAULT_URL)
    if edition == "online":
        token = (getattr(current_user, "sutui_token", None) or "").strip()
        return {"token": _mask_key(token) if token else "", "has_token": bool(token), "url": url, "edition": "online"}
    cfg = _read_sutui_config()
    token = cfg.get("token", "")
    return {
        "token": _mask_key(token) if token else "",
        "has_token": bool(token),
        "url": url,
    }


class UpdateSutuiConfig(BaseModel):
    token: Optional[str] = None
    url: Optional[str] = None


@router.post("/api/sutui/config", summary="保存速推配置（本地）")
def update_sutui_config(
    body: UpdateSutuiConfig,
    current_user: _ServerUser = Depends(get_current_user_for_local),
):
    from ..core.config import settings
    edition = (getattr(settings, "lobster_edition", None) or "online").strip().lower()
    if edition == "online":
        if body.token is not None:
            raise HTTPException(400, detail="在线版 Token 由速推登录提供，无需在此配置")
    cfg = _read_sutui_config()
    if body.token is not None and edition != "online":
        cfg["token"] = body.token.strip()
    _write_sutui_config(cfg)

    if body.url is not None and body.url.strip():
        urls = _read_upstream_urls()
        urls["sutui"] = body.url.strip()
        _write_upstream_urls(urls)
    elif not _read_upstream_urls().get("sutui"):
        urls = _read_upstream_urls()
        urls["sutui"] = _SUTUI_DEFAULT_URL
        _write_upstream_urls(urls)

    return {"ok": True, "message": "速推配置已保存"}


@router.get("/api/sutui/balance", summary="速推余额（代理到认证中心）")
async def get_sutui_balance(request: Request):
    base = _auth_server_base()
    token = request.headers.get("Authorization") or ""
    async with httpx.AsyncClient(timeout=15.0) as client:
        r = await client.get(f"{base}/api/sutui/balance", headers={"Authorization": token})
    from fastapi.responses import Response
    return Response(content=r.content, status_code=r.status_code, media_type="application/json")


# --------------- 速推充值（对接速推真实接口：get_pay_info_list / create_wx_order_info）---------------

_XSKILL_RECHARGE_URL = "https://www.xskill.ai/#/cn-recharge"
_CUSTOM_CONFIGS_FILE = _BASE_DIR / "custom_configs.json"


def _default_recharge_shops():
    """默认充值档位（当 get_pay_info_list 失败时使用）。"""
    return [
        {"shop_id": 0, "money_yuan": 100, "title": "100 元"},
        {"shop_id": 0, "money_yuan": 500, "title": "500 元"},
        {"shop_id": 0, "money_yuan": 1000, "title": "1000 元"},
    ]


def _get_custom_recharge_tiers() -> Optional[list]:
    """从 custom_configs.json 读取 RECHARGE_TIERS，用于自定义展示的档位、顺序和文案。
    格式: configs.RECHARGE_TIERS.shops = [ { \"shop_id\": 73, \"label\": \"1000元 推荐\", \"money_yuan\": 1000 }, ... ]。
    注意：实际支付金额由速推侧 shop_id 决定，label/money_yuan 仅用于展示；shop_id 需与速推商品一致。"""
    if not _CUSTOM_CONFIGS_FILE.exists():
        return None
    try:
        data = json.loads(_CUSTOM_CONFIGS_FILE.read_text(encoding="utf-8"))
        cfg = (data.get("configs") or {}).get("RECHARGE_TIERS")
        if not isinstance(cfg, dict):
            return None
        shops = cfg.get("shops")
        if not isinstance(shops, list) or not shops:
            return None
        out = []
        for s in shops:
            if not isinstance(s, dict):
                continue
            sid = s.get("shop_id")
            if sid is None:
                continue
            label = (s.get("label") or s.get("title") or "").strip() or f"{s.get('money_yuan', 0)} 元"
            money_yuan = s.get("money_yuan")
            if money_yuan is None:
                money_yuan = s.get("money")
                if isinstance(money_yuan, (int, float)) and money_yuan > 100:
                    money_yuan = money_yuan / 1000.0
            out.append({"shop_id": int(sid), "title": label, "money_yuan": float(money_yuan) if money_yuan is not None else 0, "tag": s.get("tag") or ""})
        return out if out else None
    except Exception as e:
        logger.debug("RECHARGE_TIERS read failed: %s", e)
        return None


@router.get("/api/sutui/recharge-options", summary="充值选项（代理到认证中心）")
async def get_sutui_recharge_options(request: Request):
    base = _auth_server_base()
    token = request.headers.get("Authorization") or ""
    async with httpx.AsyncClient(timeout=15.0) as client:
        r = await client.get(f"{base}/api/sutui/recharge-options", headers={"Authorization": token})
    from fastapi.responses import Response
    return Response(content=r.content, status_code=r.status_code, media_type="application/json")


class RechargeCreateBody(BaseModel):
    shop_id: int
    amount_yuan: Optional[float] = None


def _auth_server_base() -> str:
    base = (getattr(settings, "auth_server_base", None) or "").strip().rstrip("/")
    if not base:
        raise HTTPException(status_code=503, detail="未配置 AUTH_SERVER_BASE")
    return base


@router.post("/api/sutui/recharge-create", summary="创建充值订单（代理到认证中心）")
async def create_sutui_recharge(body: RechargeCreateBody, request: Request):
    base = _auth_server_base()
    token = request.headers.get("Authorization") or ""
    async with httpx.AsyncClient(timeout=15.0) as client:
        r = await client.post(
            f"{base}/api/sutui/recharge-create",
            json=body.model_dump(),
            headers={"Authorization": token, "Content-Type": "application/json"},
        )
    from fastapi.responses import Response
    return Response(content=r.content, status_code=r.status_code, media_type="application/json")
