from __future__ import annotations

from functools import lru_cache
from typing import List, Optional

from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        # 避免用户环境里有未声明变量时启动失败；业务配置以本类字段为准
        extra="ignore",
    )

    app_name: str = "龙虾 (Lobster)"
    debug: bool = True
    secret_key: str = "lobster-secret-change-me"
    cors_origins: str = "*"
    database_url: str = "sqlite:///./lobster.db"
    # MySQL/PostgreSQL 连接池（SQLite 忽略）；默认大于 SQLAlchemy 的 5+10，避免并发耗尽
    db_pool_size: int = 15
    db_max_overflow: int = 25
    db_pool_timeout: int = 60
    db_pool_recycle: int = 280
    host: str = "0.0.0.0"
    port: int = 8000
    """可选：用于生成素材文件等对外 URL 的根地址（纯 ASCII，避免编码问题）。例: http://192.168.200.57:8000。勿填 127.0.0.1（同网段设备无法预览）。"""
    public_base_url: Optional[str] = None
    """素材签名 URL 专用：本机局域网可访问根地址，如 http://192.168.1.100:8000。当 PUBLIC_BASE_URL 未设或为回环地址时优先使用（在线版多设备预览）。"""
    lan_public_base_url: Optional[str] = None
    mcp_port: int = 8001
    """本仓库为在线客户端，运行时固定为 online（忽略 LOBSTER_EDITION=standalone 等历史值）。"""
    lobster_edition: str = "online"

    @field_validator("lobster_edition", mode="before")
    @classmethod
    def _lobster_edition_fixed_online(cls, v: object) -> str:
        return "online"
    """品牌标记：与 static/branding/brands.json 的 marks 键一致（如 bihuo）。桌面快捷方式与首页 logo/文案由该标记决定。"""
    lobster_brand_mark: str = "bihuo"
    """在线版为 True 时：登录注册与充值全部自维护，不走速推；用户配置算力账号（速推 Token）用于耗算力，速推扣多少我们扣多少积分。"""
    lobster_independent_auth: bool = True
    """完成充值订单时需在请求头 X-Admin-Secret 携带此值（仅服务端/管理员使用）。"""
    lobster_recharge_admin_secret: Optional[str] = None
    """充值创建订单后展示给用户的付款说明。"""
    lobster_recharge_payment_hint: Optional[str] = None
    default_user_email: str = "user@lobster.local"
    default_user_password: str = "lobster123"
    """在线版：速推 OAuth 登录页 URL，登录成功后跳转到 /auth/sutui-callback?token=xxx"""
    sutui_oauth_login_url: Optional[str] = None
    """速推 API 根地址，用于 apikeys/list、balance 等（仅 online 使用）"""
    sutui_api_base: str = "https://api.xskill.ai"
    """我方标识，登录时带在 URL 上供速推统计（仅 online 使用）"""
    sutui_source_id: Optional[str] = None
    """充值页链接，前端「充值」按钮跳转（仅 online 使用）"""
    sutui_recharge_url: Optional[str] = None
    """是否允许 online 用户自配模型 Key；False 时统一走速推服务端模型（仅 online 使用）"""
    sutui_online_model_self_config: bool = True
    openclaw_gateway_url: Optional[str] = None
    openclaw_gateway_token: Optional[str] = None
    openclaw_agent_id: str = "main"
    """企微云端地址与转发密钥（本地轮询拉取/提交回复时使用）。"""
    wecom_cloud_url: Optional[str] = None
    wecom_forward_secret: Optional[str] = None
    # 微信服务号：服务器配置（URL/Token/EncodingAESKey）与网页授权（AppID/Secret），登录与回调均走服务器
    """服务号服务器配置 Token（公众平台 开发-基本配置 中填写，与 GET 验证一致）"""
    wechat_oa_token: Optional[str] = None
    """服务号服务器配置 EncodingAESKey（明文模式可不参与解密）"""
    wechat_oa_encoding_aes_key: Optional[str] = None
    """服务号 AppID（网页授权与 code 换 token 必填，从公众平台 基本配置 获取）"""
    wechat_oa_app_id: Optional[str] = None
    """服务号 AppSecret（网页授权换 code 必填）"""
    wechat_oa_secret: Optional[str] = None
    """服务号回调与登录跳转根地址（无公网 IP 时填服务器地址，如 https://ts-api.fyshark.com）"""
    wechat_oa_base_url: Optional[str] = None
    capability_sutui_mcp_url: Optional[str] = None
    capability_upstream_urls_json: Optional[str] = None
    reddit_comment2video_backend_url: Optional[str] = None
    """认证中心（lobster_server）根地址，必填（无默认值）：发布/素材/对话等本机接口仅通过该地址 GET /auth/me 校验 token。"""
    auth_server_base: Optional[str] = None
    """同 Bearer 在本进程内复用最近一次成功的 GET /auth/me 结果，减少并发与远端超时。秒；0=每次请求都拉远端（与旧行为一致）。"""
    auth_me_cache_ttl_seconds: int = 120
    """Twilio Account SID（可选；本页保存优先于 .env）。"""
    twilio_account_sid: Optional[str] = None
    """Twilio 控制台 Auth Token，用于校验入站 WhatsApp/SMS Webhook 的 X-Twilio-Signature。"""
    twilio_auth_token: Optional[str] = None
    """与 Twilio Sandbox「When a message comes in」里填写的 URL 完全一致（含 https、域名、路径），用于签名校验。若留空则用 request.url（反代后常需显式填写）。"""
    twilio_whatsapp_webhook_full_url: Optional[str] = None
    """在线版：本机 twilio_whatsapp_config.json 与 .env 均无 SID/Token 时，将 /api/twilio-whatsapp/* 转发到此前 lobster_server 的根 URL。未设置且 lobster_edition=online 时默认 https://lobster-server.icu；设为空字符串则关闭转发。"""
    twilio_remote_api_base: Optional[str] = None
    """创作者作品同步（Playwright）是否默认无头；与详情页「无头同步」一致，可由 perform_creator_content_sync(headless=) 覆盖。"""
    creator_sync_headless: bool = True

    def cors_origins_list(self) -> List[str]:
        if self.cors_origins.strip() == "*":
            return ["*"]
        return [x.strip() for x in self.cors_origins.split(",") if x.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
