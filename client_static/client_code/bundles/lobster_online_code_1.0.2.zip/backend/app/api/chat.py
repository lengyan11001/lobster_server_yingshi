"""Chat endpoint — direct LLM API with MCP tool-calling loop.

Primary flow:
  POST /chat → resolve model + API key → fetch MCP tools from local MCP server
  → call LLM with function definitions + messages → process tool_calls → loop
  → return final reply

POST /chat/stream: same but streams SSE progress (tool_start/tool_end) so the UI can show "thinking" steps.
Falls back to OpenClaw Gateway when no direct API config is available.
"""
from __future__ import annotations

import asyncio
import contextvars
import json
import logging
import re
import time
from pathlib import Path
from typing import Any, Awaitable, Callable, Dict, List, Optional, Tuple, Union

import httpx
from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from ..core.config import settings
from ..db import get_db
from .auth import get_current_user_for_chat, oauth2_scheme, _ServerUser
from ..models import CapabilityCallLog, ChatTurnLog, ToolCallLog, User

_BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent

logger = logging.getLogger(__name__)
router = APIRouter()

# 与龙虾主对话 system 分离：app.log 曾记录模型在此场景下输出闲聊而非 JSON（因主 system 强调必须调工具）
_REVIEW_PROMPT_DRAFTS_SYSTEM = """你是「审核后发布」定时任务的提示词草稿生成器。
【硬性约束】禁止调用任何工具；禁止编造工具或 URL；禁止与用户闲聊、反问、请用户选择下一步或列举「我可以帮你」类选项。
【你只能输出】一个 Markdown 代码块：以 ```json 开头、以 ``` 结尾；代码块外不得有任何其它文字。
【代码块内】仅一个 JSON 数组；每项为对象，必须含 "prompt" 字符串字段（后续将把该字符串作为 POST /chat 的用户消息）。"""

MAX_HISTORY = 20
MAX_TOOL_ROUNDS = 8
# 单条历史消息最大字符数，避免长回复再次送入模型导致重复/延续上一条
MAX_HISTORY_MESSAGE_CHARS = 1200
MCP_URL = "http://127.0.0.1:8001/mcp"

_URL_RE = re.compile(r'https?://[^\s"\'<>\)\]]+', re.IGNORECASE)
_pending_tool_logs: contextvars.ContextVar[List[Dict]] = contextvars.ContextVar("_pending_tool_logs", default=[])

# 对话轮内调用 MCP（如 publish_content）时附带 X-Chat-Model，供 /api/publish 走与会话一致的速推/直连模型生成文案
_mcp_forward_headers_ctx: contextvars.ContextVar[Optional[Dict[str, str]]] = contextvars.ContextVar(
    "mcp_forward_headers", default=None
)
# 单次 /chat 请求内，最近一次终态 task.get_result 解析出的成品视频 URL（publish_content 误填上游 video_id 时按 URL 反查素材库 asset_id）
_recent_task_video_urls_ctx: contextvars.ContextVar[Optional[List[str]]] = contextvars.ContextVar(
    "recent_task_video_urls", default=None
)
# 单次 /chat 请求内：task_id -> 对应 video.generate/image.generate 的 payload（供 task.get_result 终态 SSE 填 prompt/model，前端 save-url 入库）
_generation_hints_by_task_id: contextvars.ContextVar[Optional[Dict[str, Dict[str, str]]]] = (
    contextvars.ContextVar("_generation_hints_by_task_id", default=None)
)


def _generation_hints_map() -> Dict[str, Dict[str, str]]:
    m = _generation_hints_by_task_id.get()
    if m is None:
        m = {}
        _generation_hints_by_task_id.set(m)
    return m


def _register_generation_hint_for_task(
    task_id: str, invoke_payload: Any, capability_id: str
) -> None:
    tid = (task_id or "").strip()
    if not tid or not isinstance(invoke_payload, dict):
        return
    prompt = str(invoke_payload.get("prompt") or "").strip()
    model = str(invoke_payload.get("model") or invoke_payload.get("model_id") or "").strip()
    _generation_hints_map()[tid] = {
        "prompt": prompt,
        "model": model,
        "capability_id": (capability_id or "").strip(),
    }


def _apply_generation_hints_to_saved_assets(saved: List[Dict[str, Any]], task_id: str) -> None:
    tid = (task_id or "").strip()
    if not tid or not saved:
        return
    h = _generation_hints_map().get(tid)
    if not h:
        return
    prompt = (h.get("prompt") or "").strip()
    model = (h.get("model") or "").strip()
    for it in saved:
        if not isinstance(it, dict):
            continue
        if prompt and not str(it.get("prompt") or "").strip():
            it["prompt"] = prompt[:500]
        if model and not str(it.get("model") or "").strip():
            it["model"] = model[:128]
        if not str(it.get("generation_task_id") or "").strip():
            it["generation_task_id"] = tid[:128]


def _apply_invoke_payload_to_saved_assets(
    saved: List[Dict[str, Any]], invoke_args: Dict[str, Any]
) -> None:
    """image.generate 等同轮已终态时，无 task_id 映射也可用本轮 payload 填 prompt/model。"""
    if not saved or not isinstance(invoke_args, dict):
        return
    pl = invoke_args.get("payload")
    if not isinstance(pl, dict):
        return
    prompt = str(pl.get("prompt") or "").strip()
    model = str(pl.get("model") or pl.get("model_id") or "").strip()
    for it in saved:
        if not isinstance(it, dict):
            continue
        if prompt and not str(it.get("prompt") or "").strip():
            it["prompt"] = prompt[:500]
        if model and not str(it.get("model") or "").strip():
            it["model"] = model[:128]


def _terminal_saved_assets_for_task_result(result_text: str) -> List[Dict[str, Any]]:
    """task.get_result 终态：优先 MCP saved_assets，否则扫视频 URL，再尝试扫图 URL。"""
    saved = _extract_saved_assets_from_task_result(result_text)
    if saved:
        return saved
    v = _extract_video_urls_from_task_result(result_text)
    if v:
        return v
    return _extract_image_urls_from_generate_result(result_text)


def _normalize_invoke_task_get_result_args(args: Dict[str, Any]) -> Dict[str, Any]:
    """与 mcp/http_server 一致：task.get_result 只认 payload.task_id，合并 taskid/顶层误放。"""
    if not isinstance(args, dict):
        return args
    if (args.get("capability_id") or "").strip() != "task.get_result":
        return args
    payload = args.get("payload")
    if not isinstance(payload, dict):
        payload = {}
    pl = dict(payload)
    tid = (pl.get("task_id") or "").strip()
    if not tid:
        for k in ("taskId", "taskid", "TaskId"):
            v = pl.get(k)
            if isinstance(v, str) and v.strip():
                tid = v.strip()
                break
    if not tid:
        for k in ("task_id", "taskId", "taskid"):
            v = args.get(k)
            if isinstance(v, str) and v.strip():
                tid = v.strip()
                break
    if not tid:
        nested = pl.get("payload")
        if isinstance(nested, dict):
            tid = (
                (nested.get("task_id") or nested.get("taskId") or nested.get("taskid") or "")
                .strip()
            )
    if not tid:
        vid = args.get("id")
        if isinstance(vid, str) and vid.strip():
            s = vid.strip()
            if len(s) >= 16 or re.match(r"^[0-9a-fA-F-]{8,}$", s):
                tid = s
    if tid:
        pl["task_id"] = tid
    out = dict(args)
    out["payload"] = pl
    return out


_PROVIDERS: Dict[str, Dict[str, str]] = {
    "deepseek":  {"base_url": "https://api.deepseek.com",  "env": "DEEPSEEK_API_KEY"},
    "openai":    {"base_url": "https://api.openai.com",    "env": "OPENAI_API_KEY"},
    "anthropic": {"base_url": "https://api.anthropic.com", "env": "ANTHROPIC_API_KEY"},
    "google":    {"base_url": "https://generativelanguage.googleapis.com/v1beta/openai", "env": "GEMINI_API_KEY"},
}

_NO_TOOL_SUPPORT = {"deepseek-reasoner", "o3-mini"}

# 在线版：避免模型把「配置个人速推 Token」当成对用户方案（算力在 server）
_ONLINE_SYS_PREFIX = (
    "【在线版 — 对用户说明口径】速推/xskill 算力由云端 lobster_server 统一配置（如 SUTUI_SERVER_TOKEN、MCP），"
    "用户不需要、也不应再去「系统配置」填写个人速推 Token。"
    "若 invoke_capability 等工具返回「Token 未配置」「403」「认证失败」或上游错误，请如实引用工具返回的原文，"
    "并说明需排查：服务器 MCP 与 Token、本机 AUTH_SERVER_BASE 与 mcp-gateway 链路、是否已用服务器账号登录；"
    "禁止把「请用户自行配置速推 Token」作为主要解决办法。"
    "若工具返回「积分不足」「余额不足」、HTTP 402 或预扣积分失败且原文明确为余额/积分问题，必须说明是账户积分不足、需充值或购买积分，"
    "禁止将原因概括为「服务器配置错误」「服务器设置问题」或暗示管理员改服务器配置。\n\n"
)

# 速推结果里常见 cdn-video…/v3-tasks/…：对用户浏览器不保证可直连，由模型口径说明，不在后端改用户可见正文
_V3_TASKS_URL_USER_HINT = (
    "【cdn-video /v3-tasks/ 链接口径】工具或 task.get_result 若出现 https://cdn-video.51sux.com/v3-tasks/… 这类地址，"
    "是任务侧直链，**不保证**在用户浏览器里能打开；"
    "若同一 JSON 中 **saved_assets** 条目含 **source_url**（TOS/稳定公链），向用户展示「直接观看/下载」时**必须优先使用 source_url**，"
    "勿将 v3-tasks 链作为唯一或主推链接；"
    "若结果中有 saved_assets 或素材已进入「发布管理 → 素材库」，请**优先**引导用户到素材库查看成品；"
    "勿向用户保证「点链接即可看」「复制链接一定能打开」。\n"
)

_TASK_GET_RESULT_SYS_HINT = (
    "【task.get_result 专用】\n"
    "video.generate / image.generate 返回 task_id 后，**后端会自动**调用 task.get_result 并轮询直至完成，无需用户再发「不要停」「继续查」。\n"
    "调用时必须使用 invoke_capability(capability_id=\"task.get_result\", payload={\"task_id\":\"…\"})；"
    "payload 内字段名只能是 task_id（下划线），不要用 taskid、taskId。\n"
    "若用户仅追问进度且上文已有 task_id：仍应调用 task.get_result，或说明结果已在自动轮询后附于工具结果中。\n"
    "用户已粘贴任务 ID 或说「任务号是 xxx」时，把 xxx 原样填入 payload.task_id。\n"
    "若本会话中找不到任何 task_id，如实说明并请用户到「生产记录」查看最近一次生成任务 ID，或重新发起生成。\n"
)


def _no_tools_sys_hint(edition: str) -> str:
    if (edition or "").strip().lower() == "online":
        return (
            "\n【当前无可用工具】能力服务(MCP 端口 8001)未就绪。"
            "若用户要求生成图片、视频等，请说明：需本机启动 MCP，且在线版依赖 AUTH_SERVER_BASE 与服务器 mcp-gateway、SUTUI_SERVER_TOKEN；"
            "不要建议用户去「系统配置」填写个人速推 Token。"
            "可访问 http://本机IP:8000/api/health 查看 mcp.reachable 与 mcp.tools_count。\n\n"
        )
    return (
        "\n【当前无可用工具】能力服务(MCP 端口 8001)未就绪。"
        "若用户要求生成图片、视频、发布等，请回复：当前无法使用速推能力，请确认 (1) 本机已启动 MCP（端口见配置）；"
        "(2) 单机版在「系统配置」中配置速推 Token 或 .env 中 CAPABILITY_SUTUI_MCP_URL。"
        "可访问 http://本机IP:8000/api/health 查看 mcp.reachable 与 mcp.tools_count。\n\n"
    )


# ── Pydantic models ───────────────────────────────────────────────

class ChatMessage(BaseModel):
    role: str = Field(..., description="user | assistant | system")
    content: str = Field(..., description="消息内容")


class ChatRequest(BaseModel):
    message: str = Field(..., description="当前用户输入")
    history: Optional[List[ChatMessage]] = Field(default_factory=list)
    session_id: Optional[str] = None
    context_id: Optional[str] = None
    model: Optional[str] = None
    attachment_asset_ids: Optional[List[str]] = Field(default_factory=list, description="本条消息附带的素材 ID，将生成可访问 URL 供速推等使用")
    # 默认 False：智能会话等现有客户端不传该字段，行为与增加此字段前一致。
    review_prompt_drafts_only: bool = Field(
        False,
        description="审核发布「智能生成提示词」专用：禁用 MCP/工具与龙虾长 system，只产出 JSON 代码块",
    )


class ChatResponse(BaseModel):
    reply: str


# ── API key / provider resolution ─────────────────────────────────

def _all_api_keys() -> Dict[str, str]:
    """Merge keys from openclaw.json literal values and openclaw/.env."""
    keys: Dict[str, str] = {}
    try:
        p = _BASE_DIR / "openclaw" / "openclaw.json"
        if p.exists():
            text = p.read_text(encoding="utf-8")
            for pid, pd in json.loads(text).get("models", {}).get("providers", {}).items():
                if isinstance(pd, dict):
                    k = (pd.get("apiKey") or "").strip()
                    if k and not k.startswith("${"):
                        env_name = _PROVIDERS.get(pid, {}).get("env", "")
                        if env_name:
                            keys[env_name] = k
    except Exception:
        pass
    try:
        ep = _BASE_DIR / "openclaw" / ".env"
        if ep.exists():
            for line in ep.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, _, v = line.partition("=")
                    if v.strip():
                        keys[k.strip()] = v.strip()
    except Exception:
        pass
    return keys


def _resolve_config(model: str) -> Optional[Dict[str, Any]]:
    """Return {base_url, api_key, model_name, provider} or None."""
    if "/" not in model:
        return None
    provider, model_name = model.split("/", 1)
    pcfg = _PROVIDERS.get(provider)
    if not pcfg:
        return None
    api_key = _all_api_keys().get(pcfg["env"], "")
    if not api_key:
        return None
    return {
        "base_url": pcfg["base_url"],
        "api_key": api_key,
        "model_name": model_name,
        "provider": provider,
    }


def _online_resolve_cfg_and_overrides(
    payload: ChatRequest,
    raw_token: str,
) -> Tuple[Optional[str], Optional[Dict[str, Any]], Optional[str], Optional[Dict[str, str]]]:
    """在线版：model 为 sutui/xxx 时走云端 /api/sutui-chat/completions；否则用本机已配 Key 的直连模型或默认。"""
    req_model = (payload.model or "").strip()
    if req_model.startswith("sutui/"):
        inner = req_model.split("/", 1)[1]
        if not inner:
            raise HTTPException(status_code=400, detail="速推模型 ID 不能为空")
        asb = (getattr(settings, "auth_server_base", None) or "").strip().rstrip("/")
        if not asb:
            raise HTTPException(status_code=503, detail="未配置 AUTH_SERVER_BASE，无法使用速推聚合对话")
        cfg = {
            "base_url": "",
            "api_key": "",
            "model_name": inner,
            "provider": "sutui",
        }
        return (
            None,
            cfg,
            f"{asb}/api/sutui-chat/completions",
            {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {raw_token}",
            },
        )
    if req_model and "/" in req_model:
        oc = _resolve_config(req_model)
        if oc:
            return (req_model, oc, None, None)
    try:
        rm = _pick_default_model()
        return (rm, _resolve_config(rm), None, None)
    except HTTPException:
        return (None, None, None, None)


def _pick_default_model() -> str:
    """Return the first model that has a configured API key."""
    try:
        p = _BASE_DIR / "openclaw" / "openclaw.json"
        if p.exists():
            primary = json.loads(p.read_text(encoding="utf-8")).get(
                "agents", {}
            ).get("defaults", {}).get("model", {}).get("primary", "")
            if primary and _resolve_config(primary):
                return primary
    except Exception:
        pass
    for first in ["deepseek/deepseek-chat", "openai/gpt-4o",
                   "anthropic/claude-sonnet-4-5", "google/gemini-2.5-pro"]:
        if _resolve_config(first):
            return first
    raise HTTPException(
        400,
        detail="未配置任何 LLM API Key，请到「系统配置」页面添加至少一个模型的 API Key（如 DeepSeek、OpenAI 等）",
    )


# ── MCP tool helpers ──────────────────────────────────────────────

async def _fetch_mcp_tools(raw_token: Optional[str] = None) -> List[Dict]:
    """Fetch available tools from the local MCP server (port 8001)。传入用户 JWT 以便 MCP 对调试中技能过滤 list_capabilities / invoke 枚举。"""
    try:
        headers = {}
        t = (raw_token or "").strip()
        if t:
            headers["Authorization"] = f"Bearer {t}" if not t.lower().startswith("bearer ") else t
        async with httpx.AsyncClient(timeout=10.0, trust_env=False) as c:
            r = await c.post(
                MCP_URL,
                json={"jsonrpc": "2.0", "id": "lt", "method": "tools/list", "params": {}},
                headers=headers,
            )
        tools = r.json().get("result", {}).get("tools", [])
        logger.info("[对话] MCP tools/list 成功 tools_count=%s", len(tools))
        return tools
    except Exception as e:
        logger.warning("[对话] MCP tools/list 失败: %s", e)
        return []


async def get_reply_for_channel(
    user_message: str,
    session_id: str = "",
    system_prompt_extra: str = "",
) -> str:
    """供企业微信/抖音等渠道回调使用：仅文本入、文本出。优先直连 LLM，无配置时走 OpenClaw，保证本地盒子仅配 OpenClaw 也能回复。"""
    if not (user_message or "").strip():
        return "收到。"
    model = ""
    try:
        model = _pick_default_model()
    except HTTPException:
        model = "openclaw"
    cfg = _resolve_config(model) if model else None
    sys = (
        "你是智能客服助手。根据用户消息简短、友好地回复；勿假定用户当前使用的是某一特定聊天软件（除非用户主动提到）。使用中文。"
        + (("\n" + system_prompt_extra.strip()) if system_prompt_extra else "")
    )
    messages: List[Dict[str, str]] = [
        {"role": "system", "content": sys},
        {"role": "user", "content": (user_message or "").strip()},
    ]
    if cfg:
        try:
            reply = await _chat_openai(messages, cfg, [], "", sutui_token=None)
            return (reply or "").strip() or "收到。"
        except HTTPException:
            return "服务暂时不可用，请稍后再试。"
        except Exception as e:
            logger.exception("[渠道回复] chat 异常: %s", e)
            return "处理时遇到问题，请稍后再试。"
    oc_reply = await _try_openclaw(messages, model or "openclaw", "")
    if oc_reply:
        return (oc_reply or "").strip() or "收到。"
    return "抱歉，当前未配置对话模型或 OpenClaw，无法回复。"


async def get_customer_service_reply(
    user_message: str,
    company_info: str = "",
    product_intro: str = "",
    common_phrases: str = "",
    history: Optional[List[Dict[str, str]]] = None,
) -> str:
    """客服专用：仅根据提供的公司信息、产品介绍、常用话术回复；匹配不到则只做简短闲聊，严禁编造。"""
    if not (user_message or "").strip():
        return "收到。"
    materials = []
    if (company_info or "").strip():
        materials.append("【公司信息】\n" + company_info.strip())
    if (product_intro or "").strip():
        materials.append("【产品介绍】\n" + product_intro.strip())
    if (common_phrases or "").strip():
        materials.append("【常用话术】\n" + common_phrases.strip())
    materials_text = "\n\n".join(materials) if materials else "（暂无资料）"
    sys = (
        "你是智能客服助手。你必须严格遵守以下规则：\n"
        "1. 仅根据下面「公司信息」「产品介绍」「常用话术」回答与公司、产品相关的问题；勿在回复中自称或强调「企业微信」「WhatsApp」等具体渠道，除非资料里明确写了该渠道。\n"
        "2. 若用户问题无法从上述资料中匹配到任何内容，只可做简短、友好的闲聊（如问候、感谢、请稍候联系人工），严禁编造公司名、产品名、价格、规格等任何未在资料中出现的信息。\n"
        "3. 回复简短、使用中文。\n\n"
        + materials_text
    )
    messages: List[Dict[str, str]] = [{"role": "system", "content": sys}]
    if history:
        for h in history[-10:]:
            if isinstance(h, dict) and h.get("role") and h.get("content"):
                messages.append({"role": h["role"], "content": str(h["content"])[:800]})
    messages.append({"role": "user", "content": (user_message or "").strip()})
    model = ""
    try:
        model = _pick_default_model()
    except HTTPException:
        model = "openclaw"
    cfg = _resolve_config(model) if model else None
    if cfg:
        try:
            reply = await _chat_openai(messages, cfg, [], "", sutui_token=None)
            return (reply or "").strip() or "收到。"
        except HTTPException:
            return "服务暂时不可用，请稍后再试。"
        except Exception as e:
            logger.exception("[客服回复] chat 异常: %s", e)
            return "处理时遇到问题，请稍后再试。"
    oc_reply = await _try_openclaw(messages, model or "openclaw", "")
    if oc_reply:
        return (oc_reply or "").strip() or "收到。"
    return "抱歉，当前未配置对话模型，无法回复。"


def _last_user_content(cur: List[Dict]) -> str:
    """从对话列表中取最后一条用户消息的文本（用于意图纠正）。"""
    for m in reversed(cur):
        if m.get("role") != "user":
            continue
        c = m.get("content")
        if isinstance(c, str):
            return (c or "").strip()
        if isinstance(c, list):
            for p in c:
                if isinstance(p, dict) and p.get("type") == "text":
                    return (p.get("text") or "").strip()
            return ""
        return ""
    return ""


def _correct_video_to_image_if_user_asked_image(args: Dict, last_user_content: str) -> Dict:
    """模型误将图片需求选成 video.generate 时，按用户最后一条消息纠正为 image.generate，并清理 payload 仅保留图片参数（避免速推按视频处理）。"""
    if not args or (args.get("capability_id") or "").strip() != "video.generate":
        return args
    text = (last_user_content or "").strip()
    if not text:
        return args
    image_keywords = ("图片", "图", "画一张", "生成图", "一张图", "画一只", "画个", "生成一张", "来张图", "来一张", "一只猫的图", "猫的图片")
    video_keywords = ("视频", "动图", "生成视频", "做视频", "做个视频")
    has_image = any(k in text for k in image_keywords)
    has_video = any(k in text for k in video_keywords)
    if not has_image or has_video:
        return args
    args = dict(args)
    args["capability_id"] = "image.generate"
    old_payload = args.get("payload") or {}
    if not isinstance(old_payload, dict):
        old_payload = {}
    # 只保留图片能力需要的参数，去掉视频专用字段，避免传给 MCP/速推时仍被当视频
    model = (old_payload.get("model") or "").strip()
    if not model or "super-seed" in model or "st-ai" in model or "wan/" in model or "vidu" in model or "seedance" in model or "hailuo" in model or "minimax" in model:
        # 默认走 Fal 文生图，不依赖速推侧「即梦」Token 池（jimeng-* 需上游单独开通）
        model = "fal-ai/flux-2/flash"
    payload = {
        "prompt": (old_payload.get("prompt") or "").strip(),
        "model": model,
    }
    if (old_payload.get("image_url") or "").strip():
        payload["image_url"] = (old_payload.get("image_url") or "").strip()
    if (old_payload.get("image_size") or "").strip():
        payload["image_size"] = (old_payload.get("image_size") or "").strip()
    args["payload"] = payload
    logger.info("[CHAT] 根据用户意图将 video.generate 纠正为 image.generate，并已清理 payload 为仅图片参数")
    return args


_MAX_VIDEO_IMAGE_ATTACHMENTS = 9

# 本机签名直链（已禁止新上传产生；旧数据命中则拒绝对话继续）
_LOCAL_SIGNED_ASSET_PATH = "/api/assets/file/"


def _resolve_attachment_urls_strict(
    attachment_asset_ids: Optional[List[str]],
    request: Optional[Request],
    db,
    user_id: int,
) -> List[str]:
    """附图仅允许 DB 中 source_url 经 get_asset_public_url 判定为公网（TOS 或 upload-temp）。
    无公网 URL 或仍为 /api/assets/file/ 签名链时直接 HTTPException，不进入 LLM/MCP。"""
    if not attachment_asset_ids or not request:
        return []
    aids = [a.strip() for a in (attachment_asset_ids or [])[: _MAX_VIDEO_IMAGE_ATTACHMENTS] if isinstance(a, str) and a.strip()]
    if not aids:
        return []
    from .assets import get_asset_public_url

    asb = (getattr(settings, "auth_server_base", None) or "").strip().rstrip("/") or "（未配置 AUTH_SERVER_BASE）"
    out: List[str] = []
    for aid in aids:
        logger.info("[使用素材-步骤B.1] 开始处理素材 asset_id=%s", aid)
        u = get_asset_public_url(aid, user_id, request, db)
        if not u:
            logger.error(
                "[使用素材-失败] asset_id=%s get_asset_public_url=None（无 TOS/upload-temp 公网 source_url 或仅内部地址），中止对话",
                aid,
            )
            raise HTTPException(
                status_code=400,
                detail=(
                    f"素材 {aid} 没有公网可访问链接。上传时本机 TOS 与服务器 /api/assets/upload-temp 须至少成功其一；"
                    f"请配置 custom_configs.json 的 TOS_CONFIG 或检查认证中心 {asb} 与登录态后重新上传。"
                ),
            )
        if _LOCAL_SIGNED_ASSET_PATH in u:
            logger.error("[使用素材-失败] asset_id=%s 命中已禁止的签名直链 /api/assets/file/", aid)
            raise HTTPException(
                status_code=400,
                detail=f"素材 {aid} 为旧版签名链接，已不可用。请重新上传（TOS 或服务器临时上传）。",
            )
        logger.info("[使用素材-步骤B.2] 公网 URL 已解析 asset_id=%s url=%s", aid, u[:80])
        out.append(u)
    logger.info("[使用素材-步骤B.5] 附图公网 URL 齐全 count=%d asset_ids=%s", len(out), aids)
    return out


def _get_attachment_public_urls(
    attachment_asset_ids: Optional[List[str]],
    request: Optional[Request],
    db=None,
    user_id: Optional[int] = None,
) -> List[str]:
    """返回本条消息附图公网 URL（供图生视频注入）。无公网 URL 时抛 HTTPException，不再使用 build_asset_file_url。"""
    if not attachment_asset_ids or not request or db is None or user_id is None:
        return []
    return _resolve_attachment_urls_strict(attachment_asset_ids, request, db, user_id)


def _inject_video_media_urls(args: Dict[str, Any], attachment_urls: List[str]) -> None:
    """video.generate 时：若有本条消息附图的公网 URL，一律用其覆盖 payload 的 media_files/image_url/filePaths，确保速推拿到正确可拉取 URL。"""
    if not args or (args.get("capability_id") or "").strip() != "video.generate":
        return
    inner = args.get("payload")
    if not isinstance(inner, dict):
        inner = {}
        args["payload"] = inner
    if not attachment_urls:
        if not inner.get("media_files") and not inner.get("image_url") and not inner.get("filePaths"):
            logger.warning(
                "[CHAT] 图生视频未注入链接：附图为 0 个公网 URL；若用户已附图应已在对话入口被 400 拦截，此处多为文生视频或模型未带图"
            )
        return
    urls = list(attachment_urls)
    inner["filePaths"] = urls
    inner["functionMode"] = "first_last_frames"
    inner["media_files"] = urls
    inner["image_url"] = urls[0]
    existing = (inner.get("prompt") or "").strip()
    if "图生视频" not in existing:
        inner["prompt"] = ("图生视频：" + existing) if existing else "图生视频"
    logger.info("[CHAT] 图生视频注入 filePaths（%d 张）functionMode=first_last_frames", len(urls))


# 用户常在正文写「veo3.1」，但 LLM 的 tool JSON 漏传 payload.model（上游即报 generate 缺少 model；见 mcp.log）
_VEO_31_IN_USER_TEXT = re.compile(r"(?:veo|ve)\s*3[\._]?\s*1", re.IGNORECASE)
# 用户直接写速推完整 model id（与 tasks/create 一致），优先于口语「veo3.1」推断
_VEO_FULL_MODEL_SUBSTR: Tuple[Tuple[str, str], ...] = (
    ("fal-ai/veo3.1/fast/image-to-video", "fal-ai/veo3.1/fast/image-to-video"),
    ("fal-ai/veo3.1/image-to-video", "fal-ai/veo3.1/image-to-video"),
    ("fal-ai/veo3.1/fast", "fal-ai/veo3.1/fast"),
    ("fal-ai/veo3.1", "fal-ai/veo3.1"),
)


def _infer_video_model_from_user_text(
    args: Dict[str, Any],
    last_user_content: str,
    has_attachment: bool,
) -> None:
    """video.generate 且 payload 无 model 时，从用户最后一条消息补全（完整 id 优先，其次 Veo 3.1 口语）。"""
    if not args or (args.get("capability_id") or "").strip() != "video.generate":
        return
    inner = args.get("payload")
    if not isinstance(inner, dict):
        inner = {}
        args["payload"] = inner
    if (inner.get("model") or "").strip():
        return
    text = (last_user_content or "").strip()
    if not text:
        return
    low = text.lower()
    # 长串先匹配，避免 fal-ai/veo3.1 误吞 image-to-video
    for needle, canonical in _VEO_FULL_MODEL_SUBSTR:
        if needle in low:
            inner["model"] = canonical
            logger.info(
                "[CHAT] 用户正文含完整 Veo model「%s」但 payload 无 model，已补全 model=%s",
                needle,
                inner["model"],
            )
            return
    if _VEO_31_IN_USER_TEXT.search(text):
        inner["model"] = (
            "fal-ai/veo3.1/image-to-video" if has_attachment else "fal-ai/veo3.1"
        )
        logger.info(
            "[CHAT] 用户正文含 Veo 3.1 但 payload 无 model，已补全 model=%s",
            inner["model"],
        )


# 模型把素材 ID 误写入 image_url / media_files 时（非 http 链），速推侧会 422；与附图解析一致转公网 URL
_VIDEO_PAYLOAD_ASSET_ID_TOKEN = re.compile(r"^[a-f0-9]{8,64}$", re.IGNORECASE)


def _resolve_video_payload_asset_ids_to_urls(
    args: Dict[str, Any],
    request: Optional[Request],
    db,
    user_id: Optional[int],
) -> None:
    """video.generate：将 payload 中形似素材 ID 的字段解析为 get_asset_public_url 公网链。"""
    if not args or (args.get("capability_id") or "").strip() != "video.generate":
        return
    if not request or db is None or user_id is None:
        return
    inner = args.get("payload")
    if not isinstance(inner, dict):
        return
    from .assets import get_asset_public_url

    asb = (getattr(settings, "auth_server_base", None) or "").strip().rstrip("/") or "（未配置 AUTH_SERVER_BASE）"

    def resolve_one(val: Any) -> str:
        if val is None:
            return ""
        raw = str(val).strip()
        if not raw:
            return raw
        if raw.lower().startswith("http://") or raw.lower().startswith("https://"):
            return raw
        if not _VIDEO_PAYLOAD_ASSET_ID_TOKEN.match(raw):
            return raw
        aid = raw.lower()
        u = get_asset_public_url(aid, user_id, request, db)
        if not u:
            raise HTTPException(
                status_code=400,
                detail=(
                    f"视频图生参数中的素材 ID「{aid}」无法解析为公网 URL。请将该图作为本条消息附图上传，"
                    f"或确认素材库中该条目的 source_url（TOS / 服务器临时上传）有效；AUTH_SERVER_BASE={asb}。"
                ),
            )
        if _LOCAL_SIGNED_ASSET_PATH in u:
            raise HTTPException(
                status_code=400,
                detail=f"素材 {aid} 为旧版签名链接，已不可用。请重新上传后重试。",
            )
        logger.info("[CHAT] video.generate 已将参数中的 asset_id 解析为公网 URL asset_id=%s", aid)
        return u

    if inner.get("image_url") is not None:
        inner["image_url"] = resolve_one(inner.get("image_url"))
    for key in ("media_files", "filePaths"):
        v = inner.get(key)
        if isinstance(v, list):
            inner[key] = [resolve_one(x) for x in v]

    # 无附图时 _infer_video_model_from_user_text 可能写 fal-ai/veo3.1；素材 ID 已解析为公网图后须用 i2v
    m0 = (inner.get("model") or "").strip()
    if m0 == "fal-ai/veo3.1":
        img0 = (inner.get("image_url") or "").strip()
        has_http = img0.startswith("http://") or img0.startswith("https://")
        if not has_http:
            for key in ("media_files", "filePaths"):
                lv = inner.get(key)
                if not isinstance(lv, list):
                    continue
                for x in lv:
                    s = (str(x).strip() if x is not None else "")
                    if s.startswith("http://") or s.startswith("https://"):
                        has_http = True
                        break
                if has_http:
                    break
        if has_http:
            inner["model"] = "fal-ai/veo3.1/image-to-video"
            logger.info("[CHAT] Veo 3.1：payload 已含公网图，model 已从文生改为 image-to-video")


def _is_upstream_sutui_video_id_token(s: str) -> bool:
    """速推/Sora 等在 JSON 里的 video_id，形如 video_p… / video_…，不是素材库 asset_id。"""
    t = (s or "").strip()
    if len(t) < 12:
        return False
    if t.startswith("video_p") or t.startswith("video_"):
        return True
    return False


def _looks_like_v3_tasks_output_filename_asset_id(s: str) -> bool:
    """模型把 v3-tasks 成品文件名当成 asset_id，如 5d79872e01ca44cda629428792162285.mp4。"""
    t = (s or "").strip().lower()
    return bool(
        re.match(
            r"^([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}|[0-9a-f]{16,64})\.(mp4|webm|mov)$",
            t,
        )
    )


def _resolve_video_asset_by_v3_save_dedupe(db: Session, uid: int, raw_url: str):
    """v3-tasks 原始链的 save_url_dedupe 与入库一致；source_url 可能是 mcp-images，靠 dedupe 命中。"""
    from .assets import _find_existing_asset_by_save_url_dedupe, _save_url_dedupe_key

    u0 = (raw_url or "").strip().split("?")[0].split("#")[0]
    if "v3-tasks" not in u0.lower():
        return None
    dk = _save_url_dedupe_key(u0)
    return _find_existing_asset_by_save_url_dedupe(db, uid, dk)


def _collect_video_urls_from_task_result_for_publish_context(result_text: str) -> List[str]:
    out: List[str] = []
    seen: set = set()
    saved = _extract_saved_assets_from_task_result(result_text)
    for it in saved:
        if not isinstance(it, dict):
            continue
        u = (it.get("source_url") or it.get("url") or "").strip()
        if u.startswith("http"):
            k = u.split("?")[0].split("#")[0].lower()
            if k not in seen:
                seen.add(k)
                out.append(u)
    if not out:
        for it in _extract_video_urls_from_task_result(result_text):
            if not isinstance(it, dict):
                continue
            u = (it.get("url") or "").strip()
            if u.startswith("http"):
                k = u.split("?")[0].split("#")[0].lower()
                if k not in seen:
                    seen.add(k)
                    out.append(u)
    return out[:8]


# publish_content：等前端/MCP save-url 把 v3 成品写入库后再发（避免偶发「素材不存在」）
_PUBLISH_WAIT_SAVE_URL_MAX_SEC = 100.0
_PUBLISH_WAIT_SAVE_URL_INTERVAL_SEC = 0.45


def _publish_context_has_v3_tasks_url(urls: List[str]) -> bool:
    return any("v3-tasks" in (u or "").lower() for u in urls)


def _try_map_publish_content_asset_id(args: Dict[str, Any], db, user_id: Optional[int], aid_original: str) -> None:
    """单次尝试：把误填 id 映射为素材库 asset_id（不等待）。"""
    if not isinstance(args, dict) or db is None or user_id is None:
        return
    aid = (args.get("asset_id") or "").strip()
    if not aid:
        return
    from ..models import Asset

    if db.query(Asset).filter(Asset.user_id == user_id, Asset.asset_id == aid).first():
        return

    urls = list(_recent_task_video_urls_ctx.get() or [])
    url_seq = list(reversed(urls))

    def _apply_hit(hit: Any, via: str, detail: str) -> None:
        args["asset_id"] = hit.asset_id
        logger.info(
            "[CHAT] publish_content 已将误填 asset_id=%s 映射为素材库 asset_id=%s（%s %s）",
            aid_original,
            hit.asset_id,
            via,
            detail[:96] + ("…" if len(detail) > 96 else ""),
        )

    if _looks_like_v3_tasks_output_filename_asset_id(aid):
        stem = aid.lower().rsplit(".", 1)[0].replace("-", "")
        for u in url_seq:
            u_cmp = (u or "").split("?")[0].lower().replace("-", "")
            if stem and stem in u_cmp:
                hit = _resolve_video_asset_by_v3_save_dedupe(db, user_id, u)
                if hit:
                    _apply_hit(hit, "v3-dedupe", u)
                    return
        return

    if not _is_upstream_sutui_video_id_token(aid):
        return

    for u in url_seq:
        hit = _resolve_video_asset_by_v3_save_dedupe(db, user_id, u)
        if hit:
            _apply_hit(hit, "v3-dedupe", u)
            return

    for u in url_seq:
        u0 = u.split("?")[0].strip()
        tail = u0.rsplit("/", 1)[-1].lower() if "/" in u0 else ""
        q = (
            db.query(Asset)
            .filter(Asset.user_id == user_id, Asset.media_type == "video")
            .filter(Asset.source_url.isnot(None))
        )
        hit = q.filter(Asset.source_url == u0).order_by(Asset.id.desc()).first()
        if not hit and tail and tail.endswith((".mp4", ".webm", ".mov")):
            hit = (
                db.query(Asset)
                .filter(Asset.user_id == user_id, Asset.media_type == "video")
                .filter(Asset.source_url.isnot(None))
                .filter(Asset.source_url.like(f"%{tail}%"))
                .order_by(Asset.id.desc())
                .first()
            )
        if hit:
            _apply_hit(hit, "url-match", u0)
            return


def _publish_should_wait_for_save_url(urls: List[str]) -> bool:
    """本轮 task.get_result 曾带出 v3 成品链时，发布可能依赖异步 save-url/转存，需短暂等待。"""
    return _publish_context_has_v3_tasks_url(urls)


async def _normalize_publish_content_asset_id(args: Dict[str, Any], db, user_id: Optional[int]) -> None:
    """映射误填 id；若素材可能仍在 save-url/转存途中，则轮询库直至就绪或超时。"""
    if not isinstance(args, dict) or db is None or user_id is None:
        return
    aid_original = (args.get("asset_id") or "").strip()
    if not aid_original:
        return
    from ..models import Asset

    urls = list(_recent_task_video_urls_ctx.get() or [])
    need_wait = _publish_should_wait_for_save_url(urls)
    deadline = time.perf_counter() + _PUBLISH_WAIT_SAVE_URL_MAX_SEC
    logged_wait = False

    while True:
        db.expire_all()
        _try_map_publish_content_asset_id(args, db, user_id, aid_original)
        cur = (args.get("asset_id") or "").strip()
        if cur and db.query(Asset).filter(Asset.user_id == user_id, Asset.asset_id == cur).first():
            if logged_wait:
                logger.info("[CHAT] publish_content 已等待转存完成，素材就绪 asset_id=%s", cur)
            return
        if not need_wait:
            break
        if time.perf_counter() >= deadline:
            logger.warning(
                "[CHAT] publish_content 等待 save-url 入库超时(%.0fs)，仍将尝试发布 asset_id=%s",
                _PUBLISH_WAIT_SAVE_URL_MAX_SEC,
                cur or aid_original,
            )
            break
        if not logged_wait:
            logger.info(
                "[CHAT] publish_content 等待 save-url/转存完成后再发布（最多 %.0fs）…",
                _PUBLISH_WAIT_SAVE_URL_MAX_SEC,
            )
            logged_wait = True
        await asyncio.sleep(_PUBLISH_WAIT_SAVE_URL_INTERVAL_SEC)

    # 非等待路径或未等到：补打原有诊断（文件名误填且无 v3 上下文）
    db.expire_all()
    _try_map_publish_content_asset_id(args, db, user_id, aid_original)
    cur = (args.get("asset_id") or "").strip()
    if cur and db.query(Asset).filter(Asset.user_id == user_id, Asset.asset_id == cur).first():
        return
    if _looks_like_v3_tasks_output_filename_asset_id(aid_original) and not _publish_context_has_v3_tasks_url(urls):
        logger.warning(
            "[CHAT] publish_content 误填 v3 文件名 asset_id=%s，上下文无 v3 URL，无法映射",
            aid_original,
        )
        return
    cur_aid = (args.get("asset_id") or "").strip()
    if _is_upstream_sutui_video_id_token(cur_aid) or _is_upstream_sutui_video_id_token(aid_original):
        logger.warning(
            "[CHAT] publish_content 使用上游 video_id=%s，素材库仍无匹配（v3 dedupe / URL）（请确认 save-url 已成功）",
            cur_aid or aid_original,
        )


async def _exec_tool(
    name: str,
    args: Dict,
    token: str = "",
    sutui_token: Optional[str] = None,
    progress_cb: Optional[Callable[[Dict], Awaitable[None]]] = None,
    request: Optional[Request] = None,
    db: Optional[Session] = None,
    user_id: Optional[int] = None,
) -> str:
    """Execute a tool on the local MCP server and return the text result. progress_cb: 可选，用于流式推送进度（tool_start/tool_end）。"""
    if name == "invoke_capability" and (args.get("capability_id") or "").strip() == "task.get_result":
        args = _normalize_invoke_task_get_result_args(args)
    capability_id = (args.get("capability_id") or "").strip() if name == "invoke_capability" else None
    phase = None
    if capability_id == "video.generate":
        phase = "video_submit"
    elif capability_id == "image.generate":
        phase = "image_submit"
    elif capability_id == "task.get_result":
        phase = "task_polling"
    ev_start = {"type": "tool_start", "name": name, "args": list(args.keys())}
    if capability_id is not None:
        ev_start["capability_id"] = capability_id
    if phase:
        ev_start["phase"] = phase
    if progress_cb:
        try:
            await progress_cb(ev_start)
        except Exception:
            pass
    t0 = time.perf_counter()
    success = True
    result_text = ""
    # task.get_result may poll upstream for up to 30 min (video generation)
    timeout = 120.0
    if name == "invoke_capability" and (args.get("capability_id") or "").strip() == "task.get_result":
        timeout = 35 * 60.0  # 35 min
    elif name == "sync_creator_publish_data":
        timeout = 45 * 60.0  # 多账号 Playwright 同步作品数据
    elif name == "get_creator_publish_data":
        timeout = 120.0

    def _friendly_tool_error(err: Exception) -> str:
        raw = str(err or "")
        low = raw.lower()
        if (
            "getaddrinfo failed" in low
            or "name or service not known" in low
            or "nodename nor servname provided" in low
            or "temporary failure in name resolution" in low
        ):
            return (
                "网络解析失败（DNS）：无法解析上游接口域名。"
                "请检查网络/代理/DNS 配置，确认可访问速推与模型 API 域名后重试。"
            )
        if "all connection attempts failed" in low or "connection refused" in low:
            return "网络连接失败：无法连接到目标服务，请检查网络、端口或服务是否启动。"
        if "timed out" in low or "timeout" in low:
            return "请求超时：上游响应过慢，请稍后重试。"
        return f"工具调用失败: {raw}"

    if name == "publish_content" and isinstance(args, dict):
        await _normalize_publish_content_asset_id(args, db, user_id)

    try:
        hdrs: Dict[str, str] = {"Content-Type": "application/json"}
        if token:
            hdrs["Authorization"] = f"Bearer {token}"
        if sutui_token:
            hdrs["X-Sutui-Token"] = sutui_token
        _fwd = _mcp_forward_headers_ctx.get()
        if _fwd:
            for _k, _v in _fwd.items():
                if _v is not None and str(_v).strip():
                    hdrs[_k] = str(_v).strip()
        if request:
            _xi = (request.headers.get("X-Installation-Id") or request.headers.get("x-installation-id") or "").strip()
            if _xi:
                hdrs["X-Installation-Id"] = _xi
        if capability_id == "video.generate":
            pl = args.get("payload") or {}
            img = (pl.get("image_url") or "")
            mf = pl.get("media_files") or []
            logger.info(
                "[CHAT] 发 MCP video.generate payload: model=%s image_url=%s media_files=%s",
                (pl.get("model") or "(无)"),
                (img[:100] + "…") if len(img) > 100 else (img or "(无)"),
                mf,
            )
        async with httpx.AsyncClient(timeout=timeout, trust_env=False) as c:
            r = await c.post(MCP_URL, json={
                "jsonrpc": "2.0", "id": "ct",
                "method": "tools/call",
                "params": {"name": name, "arguments": args},
            }, headers=hdrs)
        try:
            body = r.json()
        except Exception:
            result_text = (r.text or "")[:2000] or f"MCP 响应非 JSON（HTTP {r.status_code}）"
            success = False
        else:
            if r.status_code >= 400:
                err = body.get("error") if isinstance(body, dict) else None
                if isinstance(err, dict):
                    result_text = str(err.get("message") or err)[:2000]
                else:
                    result_text = str(body)[:2000]
                success = False
            elif isinstance(body, dict) and body.get("error"):
                err = body.get("error")
                result_text = (
                    str(err.get("message")) if isinstance(err, dict) else str(err)
                )[:2000]
                success = False
            else:
                res = body.get("result") if isinstance(body, dict) else None
                if not isinstance(res, dict):
                    res = {}
                content = res.get("content", [])
                if isinstance(content, list) and content:
                    texts = [
                        x.get("text", "")
                        for x in content
                        if isinstance(x, dict) and x.get("type") == "text"
                    ]
                    result_text = "\n".join(t for t in texts if t) or json.dumps(content, ensure_ascii=False)
                else:
                    result_text = json.dumps(res, ensure_ascii=False)
                if res.get("isError"):
                    success = False
    except Exception as e:
        result_text = _friendly_tool_error(e)
        success = False
        logger.warning("[对话] 工具执行异常 name=%s capability_id=%s: %s", name, capability_id, e)

    ms = round((time.perf_counter() - t0) * 1000)
    logger.info("[对话] 工具执行 name=%s capability_id=%s latency_ms=%s success=%s", name, capability_id or "-", ms, success)
    if success and name == "invoke_capability" and capability_id == "task.get_result":
        if not _is_task_result_in_progress(result_text):
            vu = _collect_video_urls_from_task_result_for_publish_context(result_text)
            if vu:
                bucket = _recent_task_video_urls_ctx.get()
                if bucket is not None:
                    bucket.clear()
                    bucket.extend(vu)
    if not success and capability_id == "video.generate" and (result_text or "").strip():
        logger.warning(
            "[对话] video.generate 失败，MCP 返回正文预览（含上游 error 时请看 JSON 内 message）: %s",
            (result_text[:1200] + "…") if len(result_text) > 1200 else result_text,
        )
    urls = _URL_RE.findall(result_text)
    try:
        logs = _pending_tool_logs.get()
    except LookupError:
        logs = []
        _pending_tool_logs.set(logs)
    logs.append({
        "tool_name": name,
        "arguments": args,
        "result_text": result_text[:10000],
        "result_urls": ",".join(urls[:20]) if urls else None,
        "success": success,
        "latency_ms": ms,
    })
    ev_end = {
        "type": "tool_end",
        "name": name,
        "preview": (result_text or "")[:200],
        "success": success,
    }
    if capability_id is not None:
        ev_end["capability_id"] = capability_id
    if phase:
        ev_end["phase"] = phase
    if phase == "task_polling":
        ev_end["in_progress"] = _is_task_result_in_progress(result_text)
        if not ev_end.get("in_progress"):
            ev_end["media_type"] = _extract_media_type_from_task_result(result_text)
        logger.info(
            "[进度] task.get_result 单次返回 in_progress=%s status=%s",
            ev_end.get("in_progress"),
            _extract_status_for_log(result_text),
        )
        # 首次轮询即终态时仅此处发 saved_assets（_poll 只在「曾进行中」后补发），避免前端收不到待 save-url 的条目
        if success and not ev_end.get("in_progress"):
            sse_saved = _terminal_saved_assets_for_task_result(result_text)
            tid_poll = _task_id_from_invoke_capability_args(args)
            if sse_saved and tid_poll:
                _apply_generation_hints_to_saved_assets(sse_saved, tid_poll)
            if sse_saved:
                ev_end["saved_assets"] = sse_saved
                logger.info(
                    "[对话] task.get_result 终态 tool_end saved_assets 条数=%s task_id=%s",
                    len(sse_saved),
                    tid_poll or "-",
                )
    if success and phase == "image_submit" and capability_id == "image.generate":
        sse_saved = _extract_saved_assets_from_task_result(result_text)
        if not sse_saved:
            sse_saved = _extract_image_urls_from_generate_result(result_text)
        if sse_saved:
            _apply_invoke_payload_to_saved_assets(sse_saved, args)
            tid_img = _extract_task_id_from_result(result_text)
            if tid_img:
                _register_generation_hint_for_task(tid_img, args.get("payload") or {}, "image.generate")
                _apply_generation_hints_to_saved_assets(sse_saved, tid_img)
            ev_end["saved_assets"] = sse_saved
            logger.info(
                "[对话] image.generate SSE saved_assets 条数=%s（含 MCP 已入库或待前端 save-url）",
                len(sse_saved),
            )
    if progress_cb:
        try:
            await progress_cb(ev_end)
        except Exception:
            pass
    return result_text


_CAPABILITIES_QUESTION_RE = re.compile(
    r"(有哪些|有什么|会什么|能做什么|能干嘛|列出|介绍|说明).*?(能力|技能|功能|工具)|"
    r"(能力|技能|功能|工具).*?(有哪些|有什么|会什么|列一下|列出)|"
    r"你有哪些|你能做什么|你会什么|可以做什么|啥能力|什么能力|速推能力|MCP.*能力|内置能力",
    re.IGNORECASE | re.DOTALL,
)

# 用户问「速推有哪些模型 / 生成模型 / 模型列表」等：预拉 /api/v3/mcp/models 注入 system，避免模型胡编或贴长图
_MODELS_QUESTION_RE = re.compile(
    r"(速推|xskill).{0,24}(模型|model)|"
    r"(有哪些|有什么|列出|查询|查看|大全|全部|所有|完整|支持).{0,12}(模型|model)|"
    r"(模型|model).{0,12}(有哪些|列表|清单|大全|查询)|"
    r"生成.{0,8}(模型|用哪个)|哪个模型|什么模型",
    re.IGNORECASE,
)


async def _fetch_sutui_mcp_models_compact_text() -> str:
    """GET 速推公开模型表，仅 model_id + 展示名（与 scripts/xskill_fetch_models.py 同源接口）。"""
    base = (getattr(settings, "sutui_api_base", None) or "https://api.xskill.ai").rstrip("/")
    url = f"{base}/api/v3/mcp/models"
    async with httpx.AsyncClient(timeout=45.0, trust_env=False) as c:
        r = await c.get(url, headers={"Accept": "application/json"})
    r.raise_for_status()
    body = r.json()
    if not isinstance(body, dict):
        raise RuntimeError("mcp/models 响应不是 JSON 对象")
    data = body.get("data")
    if not isinstance(data, dict):
        raise RuntimeError("mcp/models 缺少 data 对象")
    models = data.get("models")
    if not isinstance(models, list):
        raise RuntimeError("mcp/models data.models 不是数组")
    lines: List[str] = []
    for m in models:
        if not isinstance(m, dict):
            continue
        mid = (m.get("id") or "").strip()
        name = (m.get("name") or "").strip().replace("\n", " ")
        cat = (m.get("category") or "").strip()
        lines.append(f"{mid}\t{name}\t{cat}")
    header = (
        f"共 {len(lines)} 条（{url}）。每行三列：model_id<TAB>展示名<TAB>category（image=仅文生图/图生图，用 image.generate；"
        "video=视频用 video.generate；勿把图像模型用于视频）。"
        "payload 里请填 model（与 model_id 等价）；参数边界见各模型 GET /api/v3/models/{{id}}/docs。\n"
    )
    return header + "\n".join(lines)


async def _maybe_append_sutui_models_snapshot_to_system(
    system_prompt: str,
    user_message: str,
    raw_token: str,
    request: Optional[Request],
    has_tools: bool,
) -> str:
    """用户问「有哪些模型」等时注入速推模型表，要求回答短表格、勿贴图。"""
    _ = (raw_token, request)
    if not has_tools or not (user_message or "").strip():
        return system_prompt
    if not _MODELS_QUESTION_RE.search(user_message.strip()):
        return system_prompt
    try:
        snap = await _fetch_sutui_mcp_models_compact_text()
    except Exception as e:
        logger.warning("[对话] 预拉速推模型清单失败: %s", e)
        return system_prompt
    if not (snap or "").strip():
        return system_prompt
    if len(snap) > 52000:
        snap = snap[:52000] + "\n…(已截断)"
    logger.info("[对话] 已注入速推模型清单（模型问答）len=%s", len(snap))
    return (
        system_prompt
        + "\n\n【以下为速推当前模型清单（用户正在问「有哪些模型」）；仅输出「展示名 + model_id」，"
        "可简要注明第三列 category（image 与 video 勿混用）；不要逐条写 invoke_capability 或长 payload 示例；"
        "用紧凑表格或多列排版，尽量在一次回复里多列模型；禁止 Markdown 插图、禁止长文案、禁止编造 model_id。】\n"
        + snap
    )


async def _maybe_append_capabilities_snapshot_to_system(
    system_prompt: str,
    user_message: str,
    raw_token: str,
    request: Optional[Request],
    has_tools: bool,
) -> str:
    """用户问「有哪些能力」等时，由本机预拉 list_capabilities 注入 system，避免模型不调工具、仍答泛化列表。"""
    if not has_tools or not (user_message or "").strip():
        return system_prompt
    if not _CAPABILITIES_QUESTION_RE.search(user_message.strip()):
        return system_prompt
    try:
        snap = await _exec_tool("list_capabilities", {}, raw_token, sutui_token=None, request=request)
    except Exception as e:
        logger.warning("[对话] 预拉 list_capabilities 失败: %s", e)
        return system_prompt
    if not (snap or "").strip():
        return system_prompt
    if len(snap) > 36000:
        snap = snap[:36000] + "\n…(已截断)"
    logger.info("[对话] 已注入 list_capabilities 快照（能力问答）len=%s", len(snap))
    return (
        system_prompt
        + "\n\n【以下为当前 list_capabilities 完整 JSON（用户正在问能力范围；请据此说明，须包含 "
        "capabilities、other_mcp_tools、integrations_via_app；勿忽略发布类工具与企微/WhatsApp 等集成）】\n"
        + snap
    )


# ── LLM API calls with tool-calling loop ──────────────────────────

_PROVIDER_NAMES = {
    "deepseek": "DeepSeek", "openai": "OpenAI",
    "anthropic": "Anthropic", "google": "Google Gemini",
}

def _raise_api_err(resp: httpx.Response, model: str = ""):
    detail = resp.text[:500]
    try:
        j = resp.json()
        if isinstance(j, dict):
            e = j.get("error")
            if isinstance(e, dict) and e.get("message"):
                detail = str(e.get("message"))
            elif isinstance(j.get("detail"), dict):
                e2 = j["detail"].get("error")
                if isinstance(e2, dict) and e2.get("message"):
                    detail = str(e2.get("message"))
            elif isinstance(j.get("detail"), str):
                detail = j["detail"][:2000]
    except Exception:
        pass
    if resp.status_code in (401, 403):
        provider = model.split("/", 1)[0] if "/" in model else ""
        name = _PROVIDER_NAMES.get(provider, provider or "LLM")
        raise HTTPException(
            502,
            detail=f"{name} API Key 无效或未配置，请到「系统配置」页面设置正确的 API Key。",
        )
    if resp.status_code == 402:
        raise HTTPException(status_code=402, detail=detail)
    raise HTTPException(502, detail=f"LLM API 错误 ({resp.status_code}): {detail}")


_DSML_FC_RE = re.compile(
    r'<[\uff5c|]DSML[\uff5c|]function_calls>(.*?)</[\uff5c|]DSML[\uff5c|]function_calls>',
    re.DOTALL,
)
_DSML_INVOKE_RE = re.compile(
    r'<[\uff5c|]DSML[\uff5c|]invoke\s+name="([^"]+)">(.*?)</[\uff5c|]DSML[\uff5c|]invoke>',
    re.DOTALL,
)
_DSML_PARAM_RE = re.compile(
    r'<[\uff5c|]DSML[\uff5c|]parameter\s+name="([^"]+)"\s+string="(true|false)">(.*?)</[\uff5c|]DSML[\uff5c|]parameter>',
    re.DOTALL,
)


def _parse_text_tool_calls(content: str) -> List[Dict[str, Any]]:
    """Parse DeepSeek DSML or similar text-embedded tool calls."""
    calls: List[Dict[str, Any]] = []
    for fc_match in _DSML_FC_RE.finditer(content):
        block = fc_match.group(1)
        for inv in _DSML_INVOKE_RE.finditer(block):
            name = inv.group(1)
            body = inv.group(2)
            args: Dict[str, Any] = {}
            for pm in _DSML_PARAM_RE.finditer(body):
                pname, is_str, pvalue = pm.group(1), pm.group(2), pm.group(3).strip()
                if is_str == "false":
                    try:
                        pvalue = json.loads(pvalue)
                    except Exception:
                        pass
                args[pname] = pvalue
            calls.append({"name": name, "arguments": args})
    return calls


def _strip_dsml(content: str) -> str:
    """Remove DSML markup from text content, return readable portion."""
    cleaned = _DSML_FC_RE.sub("", content).strip()
    cleaned = re.sub(r'<[\uff5c|]DSML[\uff5c|][^>]*>', '', cleaned).strip()
    return cleaned


def _reply_for_user(reply: str) -> str:
    """Strip DSML from reply so user never sees raw function_calls; use friendly text if nothing left."""
    out = _strip_dsml(reply or "").strip()
    if not out:
        return "正在处理…"
    return out


# 速推 task.get_result 状态：先判进行中再判终态，避免「未完成」等误判
_TASK_TERMINAL_STATUSES = (
    "success", "completed", "done", "succeeded", "finished",
    "failed", "error", "cancelled", "canceled", "timeout", "expired",
    "已完成", "生成成功", "成功", "完成", "失败", "错误", "取消", "超时",
)
_TASK_IN_PROGRESS_STATUSES = (
    "pending", "queued", "submitted", "processing", "generating", "running",
    "处理中", "生成中", "排队中", "运行中", "上传中", "等待中",
)


def _infer_media_type_from_asset_item(item: Any) -> Optional[str]:
    """无 media_type 字段时，根据 URL 后缀推断。"""
    if not isinstance(item, dict):
        return None
    for k in ("url", "source_url", "preview_url", "image_url", "video_url", "file_url"):
        u = (item.get(k) or "").strip().lower().split("?")[0].split("#")[0]
        if not u:
            continue
        if u.endswith((".png", ".jpg", ".jpeg", ".webp", ".gif")):
            return "image"
        if u.endswith((".mp4", ".webm", ".mov", ".m4v", ".avi")):
            return "video"
    return None


def _extract_saved_assets_from_task_result(result_text: str) -> List[Dict[str, Any]]:
    """从 task.get_result 正文解析 saved_assets 列表。"""
    if not result_text or not result_text.strip():
        return []
    raw = (result_text or "").strip()
    try:
        d = json.loads(raw) if raw.startswith("{") else {}
        saved = d.get("saved_assets") or (d.get("result") or {}).get("saved_assets")
        if isinstance(saved, list) and saved:
            return [x for x in saved if isinstance(x, dict)]
        upstream = d.get("result")
        if isinstance(upstream, dict):
            inner_result = upstream.get("result")
            if isinstance(inner_result, dict):
                content = inner_result.get("content") or []
                if content and isinstance(content[0], dict):
                    t = (content[0].get("text") or "").strip()
                    if t.startswith("{"):
                        obj = json.loads(t)
                        saved2 = obj.get("saved_assets") or []
                        if isinstance(saved2, list) and saved2:
                            return [x for x in saved2 if isinstance(x, dict)]
    except Exception:
        pass
    return []


def _find_sutui_task_output_dict(obj: Any) -> Optional[Dict[str, Any]]:
    if not isinstance(obj, dict):
        return None
    data = obj.get("data")
    if isinstance(data, dict) and isinstance(data.get("output"), dict):
        return data["output"]
    if isinstance(obj.get("output"), dict):
        return obj["output"]
    res = obj.get("result")
    if isinstance(res, dict):
        data2 = res.get("data")
        if isinstance(data2, dict) and isinstance(data2.get("output"), dict):
            return data2["output"]
    return None


def _iter_task_json_roots(d: Any) -> List[Dict[str, Any]]:
    """task.get_result 正文可能是多层 JSON 包装（含 MCP content[0].text）。"""
    out: List[Dict[str, Any]] = []
    if not isinstance(d, dict):
        return out
    out.append(d)
    r = d.get("result")
    if isinstance(r, dict):
        out.append(r)
        ir = r.get("result")
        if isinstance(ir, dict):
            for c in ir.get("content") or []:
                if isinstance(c, dict):
                    t = (c.get("text") or "").strip()
                    if t.startswith("{"):
                        try:
                            out.append(json.loads(t))
                        except Exception:
                            pass
    return out


def _primary_video_url_from_output(output: Dict[str, Any]) -> Optional[str]:
    v = output.get("video")
    if isinstance(v, str) and v.startswith("http"):
        return v.strip()
    if isinstance(v, dict):
        u = v.get("url")
        if isinstance(u, str) and u.startswith("http"):
            return u.strip()
    if isinstance(v, list):
        for item in v:
            if isinstance(item, dict):
                u = item.get("url")
                if isinstance(u, str) and u.startswith("http"):
                    return u.strip()
    vids = output.get("videos")
    if isinstance(vids, list):
        for item in vids:
            if isinstance(item, dict):
                u = item.get("url")
                if isinstance(u, str) and u.startswith("http"):
                    return u.strip()
    return None


def _extract_image_urls_from_generate_result(result_text: str) -> List[Dict[str, Any]]:
    """同步 image.generate：MCP 正文无 saved_assets 时，从 JSON 中收集图片直链，供 SSE saved_assets + 前端 save-url。"""
    if not result_text or not result_text.strip():
        return []
    raw = result_text.strip()
    if not raw.startswith("{"):
        return []
    try:
        d = json.loads(raw)
    except Exception:
        return []

    def is_image_url(u: str) -> bool:
        s = u.split("?")[0].split("#")[0].lower()
        if s.endswith((".png", ".jpg", ".jpeg", ".webp", ".gif")):
            return True
        if "/mcp-images/" in s or "/v3-tasks/" in s:
            return True
        if "/assets/" in s and not s.endswith((".mp4", ".webm", ".mov", ".m4v", ".avi")):
            return True
        if "fal.media/files" in s or "fal-cdn" in s:
            return True
        return False

    found: List[str] = []
    seen: set = set()

    def walk(obj: Any, depth: int) -> None:
        if depth > 24:
            return
        if isinstance(obj, dict):
            for v in list(obj.values())[:120]:
                walk(v, depth + 1)
        elif isinstance(obj, list):
            for x in obj[:120]:
                walk(x, depth + 1)
        elif isinstance(obj, str):
            u = obj.strip()
            if not (u.startswith("http://") or u.startswith("https://")):
                return
            if not is_image_url(u):
                return
            k = u.split("?")[0].split("#")[0].lower()
            if k in seen:
                return
            seen.add(k)
            found.append(u)

    root = d.get("result") if isinstance(d.get("result"), (dict, list)) else d
    walk(root, 0)
    return [{"url": u, "media_type": "image"} for u in found[:8]]


def _extract_video_urls_from_task_result(result_text: str) -> List[Dict[str, Any]]:
    """task.get_result 终态无 saved_assets 时，从 JSON 中收集视频直链，供 SSE saved_assets + 前端 save-url 入库。"""
    if not result_text or not result_text.strip():
        return []
    raw = result_text.strip()
    if not raw.startswith("{"):
        return []
    try:
        d = json.loads(raw)
    except Exception:
        return []

    for root in _iter_task_json_roots(d):
        od = _find_sutui_task_output_dict(root)
        if isinstance(od, dict):
            vu = _primary_video_url_from_output(od)
            if vu:
                return [{"url": vu, "media_type": "video"}]

    def is_video_url(u: str) -> bool:
        s = u.split("?")[0].split("#")[0].lower()
        if s.endswith((".mp4", ".webm", ".mov", ".m4v", ".avi", ".mkv", ".m3u8")):
            return True
        if "/v3-tasks/" in s and (".mp4" in s or ".webm" in s or ".mov" in s):
            return True
        if "fal.media" in s or "fal-cdn" in s:
            if ".mp4" in s or ".webm" in s or "/files/" in s:
                return True
        return False

    found: List[str] = []
    seen: set = set()

    def walk(obj: Any, depth: int) -> None:
        if depth > 24:
            return
        if isinstance(obj, dict):
            for v in list(obj.values())[:120]:
                walk(v, depth + 1)
        elif isinstance(obj, list):
            for x in obj[:120]:
                walk(x, depth + 1)
        elif isinstance(obj, str):
            u = obj.strip()
            if not (u.startswith("http://") or u.startswith("https://")):
                return
            if not is_video_url(u):
                return
            k = u.split("?")[0].split("#")[0].lower()
            if k in seen:
                return
            seen.add(k)
            found.append(u)

    root = d.get("result") if isinstance(d.get("result"), (dict, list)) else d
    walk(root, 0)
    return [{"url": u, "media_type": "video"} for u in found[:8]]


def _task_polling_final_progress_event(
    *,
    name: str,
    result_text: str,
    preview_len: int = 200,
    task_id: str = "",
) -> Dict[str, Any]:
    """轮询结束后补发的 tool_end：带 media_type/saved_assets，避免前端默认「视频已生成」。"""
    res = result_text or ""
    ev: Dict[str, Any] = {
        "type": "tool_end",
        "name": name,
        "preview": res[:preview_len],
        "capability_id": "task.get_result",
        "phase": "task_polling",
        "in_progress": False,
        "media_type": _extract_media_type_from_task_result(res),
    }
    saved = _terminal_saved_assets_for_task_result(res)
    tid = (task_id or "").strip()
    if saved and tid:
        _apply_generation_hints_to_saved_assets(saved, tid)
    if saved:
        ev["saved_assets"] = saved
        # 诊断：SSE 推给前端的条数；前端会对「无 asset_id」的条目各发一次 save-url
        parts: List[str] = []
        for i, it in enumerate(saved[:16]):
            if not isinstance(it, dict):
                parts.append(f"[{i}]not_dict")
                continue
            aid = (it.get("asset_id") or "").strip()
            u = (it.get("url") or it.get("source_url") or "").strip()
            parts.append(
                f"[{i}]has_asset_id={'Y' if aid else 'N'} mt={(it.get('media_type') or '?')!s} url={u[:100]}{'…' if len(u) > 100 else ''}"
            )
        logger.info(
            "[对话轮询 诊断] task.get_result 终态 SSE saved_assets 条数=%s 明细=%s",
            len(saved),
            " | ".join(parts),
        )
    else:
        logger.info("[对话轮询 诊断] task.get_result 终态 SSE 无 saved_assets（前端不会触发 save-url 批量） result_prefix=%s", res[:400])
    return ev


def _extract_media_type_from_task_result(result_text: str) -> str:
    """从 task.get_result 返回的 JSON 中解析 saved_assets[0].media_type。支持 MCP 嵌套 d.result.result.content[0].text."""
    if not result_text or not result_text.strip():
        return "video"
    raw = (result_text or "").strip()
    try:
        d = json.loads(raw) if raw.startswith("{") else {}
        for key in ("media_type", "output_media_type", "result_media_type"):
            v = d.get(key)
            if isinstance(v, str) and v.strip().lower() in ("image", "video"):
                return v.strip().lower()
        for root in _iter_task_json_roots(d):
            od = _find_sutui_task_output_dict(root)
            if isinstance(od, dict) and _primary_video_url_from_output(od):
                return "video"
        saved = d.get("saved_assets") or (d.get("result") or {}).get("saved_assets")
        if isinstance(saved, list) and saved and isinstance(saved[0], dict):
            mt = (saved[0].get("media_type") or "").strip().lower()
            if mt in ("image", "video"):
                return mt
            guess = _infer_media_type_from_asset_item(saved[0])
            if guess:
                return guess
        upstream = d.get("result")
        if isinstance(upstream, dict):
            inner_result = upstream.get("result")
            if isinstance(inner_result, dict):
                content = inner_result.get("content") or []
                if content and isinstance(content[0], dict):
                    t = (content[0].get("text") or "").strip()
                    if t.startswith("{"):
                        obj = json.loads(t)
                        saved = obj.get("saved_assets") or []
                        if isinstance(saved, list) and saved and isinstance(saved[0], dict):
                            mt = (saved[0].get("media_type") or "").strip().lower()
                            if mt in ("image", "video"):
                                return mt
                            guess = _infer_media_type_from_asset_item(saved[0])
                            if guess:
                                return guess
    except Exception:
        pass
    return "video"


def _extract_status_for_log(result_text: str) -> str:
    """从 task.get_result 返回文本中解析 status，仅用于日志。路径见 docs/图生视频_MCP调用流程与参数.md"""
    if not result_text or not result_text.strip():
        return "?"
    raw = (result_text or "").strip()

    def _get_status(obj: Any) -> str:
        if not isinstance(obj, dict):
            return ""
        s = (obj.get("status") or "").strip()
        if s:
            return s
        res = obj.get("result")
        if isinstance(res, dict):
            content = res.get("content") or []
            for c in content[:3]:
                if isinstance(c, dict):
                    t = (c.get("text") or "").strip()
                    if t.startswith("{"):
                        try:
                            inner = json.loads(t)
                            s = (inner.get("status") or _get_status(inner.get("result") or {}) or "").strip()
                            if s:
                                return s
                        except Exception:
                            pass
        return ""

    try:
        d = json.loads(raw) if raw.startswith("{") else {}
        if not d:
            for part in (raw.split("```") or [raw]):
                part = part.strip()
                if part.startswith("{") and "status" in part:
                    try:
                        d = json.loads(part)
                        break
                    except Exception:
                        pass
        if not d:
            return "?"
        upstream = d.get("result")
        if isinstance(upstream, dict):
            inner_result = upstream.get("result")
            if isinstance(inner_result, dict):
                content = inner_result.get("content") or []
                if content and isinstance(content[0], dict):
                    t = (content[0].get("text") or "").strip()
                    if t.startswith("{"):
                        try:
                            obj = json.loads(t)
                            s = (obj.get("status") or "").strip()
                            if s:
                                return s
                        except Exception:
                            pass
        s = _get_status(d) or _get_status(upstream or {})
        if s:
            return s
        m = re.search(r'"status"\s*:\s*"([^"]*)"', raw)
        if m and m.group(1).strip():
            return m.group(1).strip()
        return "?"
    except Exception:
        pass
    m = re.search(r'"status"\s*:\s*"([^"]*)"', (result_text or ""))
    if m and m.group(1).strip():
        return m.group(1).strip()
    return "?"


def _is_task_result_in_progress(result_text: str) -> bool:
    """True if task.get_result 表示仍在进行中（需继续 15s 轮询）。先判进行中再判终态，避免「未完成」等误判为终态."""
    if not result_text or not result_text.strip():
        return True  # 无内容时继续轮询，避免误报「已生成」
    raw = (result_text or "").strip()
    status_val = _extract_status_for_log(result_text)
    if status_val and status_val != "?":
        s = status_val.strip().lower()
        for term in _TASK_IN_PROGRESS_STATUSES:
            if s == term.lower():
                return True
        for term in _TASK_TERMINAL_STATUSES:
            if s == term.lower():
                return False
        return True
    raw_lower = raw.lower()
    if '"status":"completed"' in raw_lower or '"status":"success"' in raw_lower or '"status":"failed"' in raw_lower:
        return False
    if "未完成" in raw or "未成功" in raw:
        return True
    for s in _TASK_IN_PROGRESS_STATUSES:
        if s in raw_lower or f'"status":"{s}"' in raw_lower:
            return True
    for s in _TASK_TERMINAL_STATUSES:
        if s not in raw_lower:
            continue
        if s in ("完成", "成功") and ("未完成" in raw or "未成功" in raw):
            continue
        return False
    return True


def _task_result_hint(result_text: str) -> str:
    """从 task.get_result 返回文本中提取一句简短状态，供前端展示「查询结果」。status 与 _extract_status_for_log 同路径."""
    if not result_text or not result_text.strip():
        return ""
    status = _extract_status_for_log(result_text)
    if status and status != "?":
        if _is_task_result_in_progress(result_text):
            return f"当前状态: {status}"
        return f"结果: {status}"
    if _is_task_result_in_progress(result_text):
        return "当前状态: 仍生成中"
    return "结果: 已完成"


def _extract_task_id_from_result(result_text: str) -> str:
    """从 video.generate 或 task.get_result 的返回文本中解析 task_id。路径与 status 一致：d.result.result.content[0].text."""
    if not result_text or not result_text.strip():
        return ""
    raw = (result_text or "").strip()
    try:
        d = json.loads(raw) if raw.startswith("{") else {}
        if not d:
            return ""
        tid = (d.get("task_id") or "").strip()
        if tid:
            return tid
        upstream = d.get("result")
        if isinstance(upstream, dict):
            tid = (upstream.get("task_id") or "").strip()
            if tid:
                return tid
            inner_result = upstream.get("result")
            if isinstance(inner_result, dict):
                content = inner_result.get("content") or []
                if content and isinstance(content[0], dict):
                    t = (content[0].get("text") or "").strip()
                    if t.startswith("{"):
                        obj = json.loads(t)
                        tid = (obj.get("task_id") or "").strip()
                        if tid:
                            return tid
        return ""
    except Exception:
        return ""


def _task_id_from_invoke_capability_args(args: Dict[str, Any]) -> str:
    pl = args.get("payload") if isinstance(args.get("payload"), dict) else {}
    return (pl.get("task_id") or args.get("task_id") or "").strip()


async def _poll_task_get_result_until_terminal(
    invoke_args: Dict[str, Any],
    initial_res: str,
    token: str,
    sutui_token: Optional[str],
    progress_cb: Optional[Callable[[Dict], Awaitable[None]]],
    request: Optional[Request],
) -> str:
    """task.get_result 首次返回仍「进行中」时，15s 间隔轮询直至终态（与 MCP 长超时配合）。"""
    if (invoke_args.get("capability_id") or "").strip() != "task.get_result":
        return initial_res
    if not _is_task_result_in_progress(initial_res):
        return initial_res
    res = initial_res
    poll_interval = 15
    max_wait_sec = 20 * 60
    waited = 0
    task_id = _task_id_from_invoke_capability_args(invoke_args)
    entered_poll_loop = False
    while waited < max_wait_sec:
        await asyncio.sleep(poll_interval)
        waited += poll_interval
        entered_poll_loop = True
        logger.info("[CHAT] task.get_result 轮询 %ds task_id=%s", waited, task_id or "(无)")
        res = await _exec_tool(
            "invoke_capability", invoke_args, token, sutui_token, progress_cb=None, request=request
        )
        if progress_cb:
            try:
                ev = {"type": "task_poll", "message": f"正在查询生成结果…（{waited}秒）"}
                if task_id:
                    ev["task_id"] = task_id
                ev["result_hint"] = _task_result_hint(res)
                await progress_cb(ev)
            except Exception:
                pass
        if not _is_task_result_in_progress(res):
            break
    # 仅当「曾处于进行中并进入过轮询」后再补发终态 saved_assets，避免与首次终态的 _exec_tool tool_end 重复
    if progress_cb and entered_poll_loop:
        try:
            await progress_cb(
                _task_polling_final_progress_event(
                    name="invoke_capability",
                    result_text=res or "",
                    task_id=task_id,
                )
            )
            await progress_cb({"type": "status", "message": "正在生成回复…"})
        except Exception:
            pass
    return res


async def _after_generate_auto_task_result(
    invoke_args: Dict[str, Any],
    gen_res: str,
    token: str,
    sutui_token: Optional[str],
    progress_cb: Optional[Callable[[Dict], Awaitable[None]]],
    request: Optional[Request],
) -> str:
    """video/image.generate 返回 task_id 后，不依赖模型下一轮再调 task.get_result，由后端自动拉结果并轮询。"""
    cap = (invoke_args.get("capability_id") or "").strip()
    if cap not in ("video.generate", "image.generate"):
        return gen_res
    tid = _extract_task_id_from_result(gen_res)
    if not tid:
        return gen_res
    pl0 = invoke_args.get("payload") if isinstance(invoke_args.get("payload"), dict) else {}
    _register_generation_hint_for_task(tid, pl0, cap)
    poll_a = _normalize_invoke_task_get_result_args(
        {
            "capability_id": "task.get_result",
            "payload": {"task_id": tid, "capability_id": cap},
        }
    )
    res = await _exec_tool(
        "invoke_capability",
        poll_a,
        token,
        sutui_token,
        progress_cb=progress_cb,
        request=request,
    )
    return await _poll_task_get_result_until_terminal(
        poll_a, res, token, sutui_token, progress_cb, request
    )


async def _chat_openai(
    msgs: List[Dict],
    cfg: Dict,
    mcp_tools: List[Dict],
    token: str,
    sutui_token: Optional[str] = None,
    progress_cb: Optional[Callable[[Dict], Awaitable[None]]] = None,
    attachment_urls: Optional[List[str]] = None,
    override_url: Optional[str] = None,
    override_headers: Optional[Dict[str, str]] = None,
    request: Optional[Request] = None,
    db: Optional[Session] = None,
    user_id: Optional[int] = None,
) -> str:
    """OpenAI-compatible chat loop (DeepSeek, OpenAI, Google Gemini)."""
    attachment_urls = attachment_urls or []
    if override_url and override_headers:
        url = override_url
        hdrs = dict(override_headers)
    else:
        base = cfg["base_url"].rstrip("/")
        if "googleapis.com" in base or base.endswith("/v1"):
            url = f"{base}/chat/completions"
        else:
            url = f"{base}/v1/chat/completions"

        hdrs = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {cfg['api_key']}",
        }
    model = cfg["model_name"]
    use_tools = model not in _NO_TOOL_SUPPORT and bool(mcp_tools)
    oai_tools = [
        {
            "type": "function",
            "function": {
                "name": t["name"],
                "description": t.get("description", ""),
                "parameters": t.get("inputSchema", {"type": "object", "properties": {}}),
            },
        }
        for t in mcp_tools
    ] if use_tools else []

    _ACTION_KW = re.compile(
        r"(发布|生成|打开浏览器|帮你|开始|正在|马上|登录|查看素材|查看账号|"
        r"invoke_capability|publish_content|publish_youtube_video|list_youtube_accounts|"
        r"open_account_browser|list_assets|get_creator_publish_data|sync_creator_publish_data)",
        re.IGNORECASE,
    )
    # 仅当用户当前消息包含操作意图时才强制要求调用工具，避免对「你好」等问候误触发
    _USER_ACTION_KW = re.compile(
        r"(帮我|给我|生成.*图|发.*抖音|发布到|YouTube|youtube|发到YouTube|打开浏览器|登录|查看素材|查看账号|"
        r"invoke_capability|publish_content|publish_youtube_video|list_youtube_accounts|"
        r"open_account_browser|list_assets|生成图片|发布内容|"
        r"发布数据|作品数据|同步.*数据|播放量|get_creator_publish_data|sync_creator_publish_data)",
        re.IGNORECASE,
    )
    force_tool_retry_done = False

    cur = list(msgs)
    for rnd in range(MAX_TOOL_ROUNDS):
        body: Dict[str, Any] = {"model": model, "messages": cur, "stream": False}
        if oai_tools and rnd < MAX_TOOL_ROUNDS - 1:
            body["tools"] = oai_tools
            body["tool_choice"] = "auto"

        async with httpx.AsyncClient(timeout=120.0, trust_env=False) as c:
            resp = await c.post(url, json=body, headers=hdrs)
        if resp.status_code != 200:
            _raise_api_err(resp, model=f"{cfg.get('provider','')}/{cfg.get('model_name','')}")

        choice = (resp.json().get("choices") or [{}])[0]
        msg = choice.get("message", {})
        tcs = msg.get("tool_calls", [])

        if tcs:
            cur.append(msg)
            last_user_content = _last_user_content(cur)
            for tc in tcs:
                fn = tc.get("function", {})
                try:
                    a = json.loads(fn.get("arguments", "{}"))
                except Exception:
                    a = {}
                if fn.get("name") == "invoke_capability":
                    a = _correct_video_to_image_if_user_asked_image(a, last_user_content)
                    _inject_video_media_urls(a, attachment_urls)
                    _infer_video_model_from_user_text(a, last_user_content, bool(attachment_urls))
                    _resolve_video_payload_asset_ids_to_urls(a, request, db, user_id)
                logger.info("[CHAT] tool_call: %s(%s)", fn.get("name"), list(a.keys()))
                if fn.get("name") == "invoke_capability" and (a.get("capability_id") or "").strip() == "media.edit":
                    pl0 = a.get("payload") if isinstance(a.get("payload"), dict) else {}
                    logger.info(
                        "[CHAT] media.edit payload operation=%s asset_id=%s",
                        pl0.get("operation"),
                        pl0.get("asset_id"),
                    )
                res = await _exec_tool(
                    fn.get("name", ""),
                    a,
                    token,
                    sutui_token,
                    progress_cb=progress_cb,
                    request=request,
                    db=db,
                    user_id=user_id,
                )
                if fn.get("name") == "invoke_capability" and (a.get("capability_id") or "").strip() == "media.edit":
                    logger.info(
                        "[CHAT] media.edit result preview=%s",
                        (res or "")[:800],
                    )
                if fn.get("name") == "invoke_capability":
                    res = await _after_generate_auto_task_result(
                        a, res, token, sutui_token, progress_cb, request
                    )
                if (
                    fn.get("name") == "invoke_capability"
                    and (a.get("capability_id") or "").strip() == "task.get_result"
                    and _is_task_result_in_progress(res)
                ):
                    res = await _poll_task_get_result_until_terminal(
                        a, res, token, sutui_token, progress_cb, request
                    )
                cur.append({
                    "role": "tool",
                    "tool_call_id": tc.get("id", ""),
                    "content": res,
                })
            continue

        content = (msg.get("content") or "").strip()
        logger.info("[CHAT] rnd=%d no tool_calls, content_len=%d", rnd, len(content))

        text_calls = _parse_text_tool_calls(content) if content else []
        if text_calls and rnd < MAX_TOOL_ROUNDS - 1:
            logger.info("[CHAT] parsed %d text-embedded tool calls (round %d)", len(text_calls), rnd)
            preamble = _strip_dsml(content)
            cur.append({"role": "assistant", "content": preamble or "正在调用工具..."})
            results = []
            last_user_content = _last_user_content(cur)
            for tc_info in text_calls:
                if tc_info["name"] == "invoke_capability":
                    tc_info["arguments"] = _correct_video_to_image_if_user_asked_image(tc_info["arguments"], last_user_content)
                    _inject_video_media_urls(tc_info["arguments"], attachment_urls)
                    _infer_video_model_from_user_text(tc_info["arguments"], last_user_content, bool(attachment_urls))
                    _resolve_video_payload_asset_ids_to_urls(tc_info["arguments"], request, db, user_id)
                logger.info("[CHAT] text_tool_call: %s(%s)", tc_info["name"], list(tc_info["arguments"].keys()))
                ta = tc_info["arguments"]
                if tc_info["name"] == "invoke_capability" and (ta.get("capability_id") or "").strip() == "media.edit":
                    pl1 = ta.get("payload") if isinstance(ta.get("payload"), dict) else {}
                    logger.info(
                        "[CHAT] media.edit payload operation=%s asset_id=%s",
                        pl1.get("operation"),
                        pl1.get("asset_id"),
                    )
                res = await _exec_tool(
                    tc_info["name"],
                    tc_info["arguments"],
                    token,
                    sutui_token,
                    progress_cb=progress_cb,
                    request=request,
                    db=db,
                    user_id=user_id,
                )
                if tc_info["name"] == "invoke_capability" and (ta.get("capability_id") or "").strip() == "media.edit":
                    logger.info(
                        "[CHAT] media.edit result preview=%s",
                        (res or "")[:800],
                    )
                if tc_info["name"] == "invoke_capability":
                    res = await _after_generate_auto_task_result(
                        tc_info["arguments"], res, token, sutui_token, progress_cb, request
                    )
                if (
                    tc_info["name"] == "invoke_capability"
                    and (tc_info["arguments"].get("capability_id") or "").strip() == "task.get_result"
                    and _is_task_result_in_progress(res)
                ):
                    res = await _poll_task_get_result_until_terminal(
                        tc_info["arguments"], res, token, sutui_token, progress_cb, request
                    )
                results.append(f"[{tc_info['name']}] {res}")
            cur.append({"role": "user", "content": "工具调用结果:\n" + "\n\n".join(results) + "\n\n请根据以上结果回答用户。"})
            continue

        # 用户明确要求执行操作、且助手只回了文字没调工具时，强制要求调工具（不因「已成功」等总结语放过）
        last_user_msg = ""
        for m in reversed(cur):
            if m.get("role") == "user":
                last_user_msg = (m.get("content") or "").strip()
                break
        if (
            oai_tools
            and rnd == 0
            and not force_tool_retry_done
            and _ACTION_KW.search(content)
            and _USER_ACTION_KW.search(last_user_msg)
        ):
            logger.warning(
                "[CHAT] LLM replied with action text but NO tool_call (user asked for action). "
                "Retrying with tool_choice=required. Content preview: %s",
                content[:200],
            )
            force_tool_retry_done = True
            cur.append({"role": "assistant", "content": content})
            cur.append({
                "role": "user",
                "content": (
                    "你刚才只回复了文字，没有调用任何工具。"
                    "请立即调用对应的工具来执行操作（如 publish_content、invoke_capability、open_account_browser 等），"
                    "不要只用文字描述。"
                ),
            })
            body_retry: Dict[str, Any] = {
                "model": model, "messages": cur, "stream": False,
                "tools": oai_tools, "tool_choice": "required",
            }
            async with httpx.AsyncClient(timeout=120.0, trust_env=False) as c:
                resp2 = await c.post(url, json=body_retry, headers=hdrs)
            if resp2.status_code == 200:
                choice2 = (resp2.json().get("choices") or [{}])[0]
                msg2 = choice2.get("message", {})
                tcs2 = msg2.get("tool_calls", [])
                if tcs2:
                    logger.info("[CHAT] forced retry produced %d tool_calls", len(tcs2))
                    cur.append(msg2)
                    last_user_content = _last_user_content(cur)
                    for tc in tcs2:
                        fn = tc.get("function", {})
                        try:
                            a = json.loads(fn.get("arguments", "{}"))
                        except Exception:
                            a = {}
                        if fn.get("name") == "invoke_capability":
                            a = _correct_video_to_image_if_user_asked_image(a, last_user_content)
                            _inject_video_media_urls(a, attachment_urls)
                            _infer_video_model_from_user_text(a, last_user_content, bool(attachment_urls))
                            _resolve_video_payload_asset_ids_to_urls(a, request, db, user_id)
                        logger.info("[CHAT] tool_call(forced): %s(%s)", fn.get("name"), list(a.keys()))
                        res = await _exec_tool(
                            fn.get("name", ""),
                            a,
                            token,
                            sutui_token,
                            progress_cb=progress_cb,
                            request=request,
                            db=db,
                            user_id=user_id,
                        )
                        if fn.get("name") == "invoke_capability":
                            res = await _after_generate_auto_task_result(
                                a, res, token, sutui_token, progress_cb, request
                            )
                        if (
                            fn.get("name") == "invoke_capability"
                            and (a.get("capability_id") or "").strip() == "task.get_result"
                            and _is_task_result_in_progress(res)
                        ):
                            res = await _poll_task_get_result_until_terminal(
                                a, res, token, sutui_token, progress_cb, request
                            )
                        cur.append({
                            "role": "tool",
                            "tool_call_id": tc.get("id", ""),
                            "content": res,
                        })
                    continue
                else:
                    logger.warning("[CHAT] forced retry still no tool_calls")

        if oai_tools and rnd == 0:
            _FAKE_PATTERN = re.compile(
                r"(已为你|已成功|已生成|已发布|发布成功|生成完成|"
                r"!\[.*\]\(https?://|https?://.*\.(jpg|png|mp4))",
                re.IGNORECASE,
            )
            if _FAKE_PATTERN.search(content):
                logger.warning("[CHAT] possible fabricated result (no tools called): %s", content[:300])
                try:
                    logs = _pending_tool_logs.get()
                except LookupError:
                    logs = []
                if not logs:
                    content += "\n\n⚠️ 注意：以上回复可能是AI模拟的结果，并非真实执行。如需真正执行操作，请再次明确告诉我。"

        return _reply_for_user(content)

    return "（工具调用轮数已达上限）"


async def _chat_anthropic(
    msgs: List[Dict],
    cfg: Dict,
    mcp_tools: List[Dict],
    token: str,
    sutui_token: Optional[str] = None,
    progress_cb: Optional[Callable[[Dict], Awaitable[None]]] = None,
    attachment_urls: Optional[List[str]] = None,
    request: Optional[Request] = None,
    db: Optional[Session] = None,
    user_id: Optional[int] = None,
) -> str:
    """Anthropic Messages API chat loop."""
    attachment_urls = attachment_urls or []
    hdrs = {
        "Content-Type": "application/json",
        "x-api-key": cfg["api_key"],
        "anthropic-version": "2023-06-01",
    }
    sys_text = ""
    ant_msgs: List[Dict] = []
    for m in msgs:
        if m["role"] == "system":
            sys_text = m["content"]
        elif m["role"] in ("user", "assistant"):
            ant_msgs.append({"role": m["role"], "content": m["content"]})

    ant_tools = [
        {
            "name": t["name"],
            "description": t.get("description", ""),
            "input_schema": t.get("inputSchema", {"type": "object", "properties": {}}),
        }
        for t in mcp_tools
    ]

    for rnd in range(MAX_TOOL_ROUNDS):
        body: Dict[str, Any] = {
            "model": cfg["model_name"],
            "max_tokens": 4096,
            "messages": ant_msgs,
        }
        if sys_text:
            body["system"] = sys_text
        if ant_tools and rnd < MAX_TOOL_ROUNDS - 1:
            body["tools"] = ant_tools

        async with httpx.AsyncClient(timeout=120.0, trust_env=False) as c:
            resp = await c.post(
                "https://api.anthropic.com/v1/messages", json=body, headers=hdrs,
            )
        if resp.status_code != 200:
            _raise_api_err(resp, model="anthropic/" + cfg.get("model_name", ""))

        data = resp.json()
        blocks = data.get("content", [])
        tus = [b for b in blocks if b.get("type") == "tool_use"]

        if tus and data.get("stop_reason") == "tool_use":
            ant_msgs.append({"role": "assistant", "content": blocks})
            results = []
            last_user_content = _last_user_content(ant_msgs)
            for tu in tus:
                inp = dict(tu.get("input") or {})
                if tu.get("name") == "invoke_capability":
                    inp = _correct_video_to_image_if_user_asked_image(inp, last_user_content)
                    _inject_video_media_urls(inp, attachment_urls)
                    _infer_video_model_from_user_text(inp, last_user_content, bool(attachment_urls))
                    _resolve_video_payload_asset_ids_to_urls(inp, request, db, user_id)
                logger.info("tool_call: %s", tu["name"])
                r = await _exec_tool(
                    tu["name"],
                    inp,
                    token,
                    sutui_token,
                    progress_cb=progress_cb,
                    request=request,
                    db=db,
                    user_id=user_id,
                )
                if tu.get("name") == "invoke_capability":
                    r = await _after_generate_auto_task_result(
                        inp, r, token, sutui_token, progress_cb, request
                    )
                if (
                    tu.get("name") == "invoke_capability"
                    and (inp.get("capability_id") or "").strip() == "task.get_result"
                    and _is_task_result_in_progress(r)
                ):
                    r = await _poll_task_get_result_until_terminal(
                        inp, r, token, sutui_token, progress_cb, request
                    )
                results.append({
                    "type": "tool_result",
                    "tool_use_id": tu["id"],
                    "content": r,
                })
            ant_msgs.append({"role": "user", "content": results})
            continue

        text_parts = [
            b.get("text", "") for b in blocks if b.get("type") == "text"
        ]
        return "\n".join(text_parts).strip() or "（无回复内容）"

    return "（工具调用轮数已达上限）"


# ── OpenClaw Gateway fallback ─────────────────────────────────────

def _openclaw_fallback_model() -> str:
    """当未配置直连 LLM 时，OpenClaw 回退使用的模型（与 openclaw.json agents.defaults.model.primary 一致）。"""
    try:
        p = _BASE_DIR / "openclaw" / "openclaw.json"
        if p.exists():
            data = json.loads(p.read_text(encoding="utf-8"))
            primary = (
                (data.get("agents") or {}).get("defaults") or {}
            ).get("model") or {}
            if isinstance(primary, dict):
                pv = (primary.get("primary") or "").strip()
                if pv and "/" in pv:
                    return pv
    except Exception:
        pass
    return "anthropic/claude-sonnet-4-5"


async def _try_openclaw(
    msgs: List[Dict], model: str, raw_token: str,
) -> Optional[str]:
    """Attempt to get a reply via OpenClaw Gateway. Returns None on failure."""
    oc_base = (settings.openclaw_gateway_url or "").strip().rstrip("/")
    oc_token = (settings.openclaw_gateway_token or "").strip()
    if not oc_base or not oc_token:
        return None

    agent_id = "main"
    if model and "/" in model:
        slug = re.sub(
            r'[^a-z0-9_-]', '-',
            model.lower().replace("/", "-").replace(".", "-"),
        )
        agent_id = re.sub(r'-+', '-', slug).strip('-')[:64] or "main"

    try:
        async with httpx.AsyncClient(timeout=120.0, trust_env=False) as c:
            resp = await c.post(
                f"{oc_base}/v1/chat/completions",
                json={"model": model, "messages": msgs, "stream": False},
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {oc_token}",
                    "x-openclaw-agent-id": agent_id,
                    "x-user-authorization": f"Bearer {raw_token}",
                },
            )
        if resp.status_code == 200:
            choices = resp.json().get("choices", [])
            if choices:
                return (choices[0].get("message", {}).get("content") or "").strip()
    except Exception:
        pass
    return None


# ── Chat turn logging ─────────────────────────────────────────────

def _flush_tool_logs(db: Session, uid: int, session_id: Optional[str], model: Optional[str]):
    """Persist collected tool call records to the database."""
    try:
        logs = _pending_tool_logs.get()
    except LookupError:
        return
    for entry in logs:
        db.add(ToolCallLog(
            user_id=uid,
            tool_name=entry["tool_name"],
            arguments=entry.get("arguments"),
            result_text=entry.get("result_text"),
            result_urls=entry.get("result_urls"),
            success=entry.get("success", True),
            latency_ms=entry.get("latency_ms"),
            session_id=(session_id or "")[:128] or None,
            model=(model or "")[:128] or None,
        ))
    _pending_tool_logs.set([])


def _log_turn(
    db: Session, uid: int, user_msg: str, reply: str,
    sid: Optional[str], cid: Optional[str], meta: Optional[Dict] = None,
):
    db.add(ChatTurnLog(
        user_id=uid,
        session_id=(sid or "")[:128] or None,
        context_id=(cid or "")[:128] or None,
        user_message=(user_msg or "")[:5000],
        assistant_reply=(reply or "")[:20000],
        meta=meta or {},
    ))


# ── Main endpoint ─────────────────────────────────────────────────

def _build_user_content_with_attachments(
    payload: ChatRequest,
    request: Optional[Request] = None,
    db=None,
    user_id: Optional[int] = None,
) -> str:
    user_content = (payload.message or "").strip()
    if getattr(payload, "attachment_asset_ids", None) and request and db is not None and user_id is not None:
        from backend.app.api.assets import get_asset_public_url

        pairs = []
        aids = [a.strip() for a in (payload.attachment_asset_ids or [])[:5] if isinstance(a, str) and a.strip()]
        asb = (getattr(settings, "auth_server_base", None) or "").strip().rstrip("/") or "（未配置 AUTH_SERVER_BASE）"
        for aid in aids:
            u = get_asset_public_url(aid, user_id, request, db)
            if not u:
                logger.error("[CHAT] 附图无公网 URL，中止组装用户消息 asset_id=%s", aid)
                raise HTTPException(
                    status_code=400,
                    detail=(
                        f"素材 {aid} 没有公网可访问链接。请配置 TOS_CONFIG 或确保 {asb}/api/assets/upload-temp 可用后重新上传。"
                    ),
                )
            if _LOCAL_SIGNED_ASSET_PATH in u:
                logger.error("[CHAT] 附图为已禁止的签名直链 asset_id=%s", aid)
                raise HTTPException(
                    status_code=400,
                    detail=f"素材 {aid} 为旧版签名链接，已不可用。请重新上传。",
                )
            pairs.append((aid, u))
        if pairs:
            logger.info("[CHAT] 注入素材 URL: asset_ids=%s", [p[0] for p in pairs])
            user_content += "\n\n【用户本条消息上传的素材】生成视频时请使用以下 URL 作为 image_url，勿使用历史中的其他素材。\n"
            user_content += "\n".join(f"- asset_id: {aid}  URL: {u}" for aid, u in pairs)
    return user_content or "（无文字）"


@router.post("/chat", response_model=ChatResponse, summary="智能对话")
async def chat_endpoint(
    request: Request,
    payload: ChatRequest,
    raw_token: str = Depends(oauth2_scheme),
    current_user: Union[User, _ServerUser] = Depends(get_current_user_for_chat),
    db: Session = Depends(get_db),
):
    _pending_tool_logs.set([])

    edition = (getattr(settings, "lobster_edition", None) or "online").strip().lower()
    if edition == "online":
        model = "sutui"
        # 速推由服务器 MCP + SUTUI_SERVER_TOKEN 处理；本机 MCP 经 mcp-gateway 转发，此处不传用户速推 Token
        sutui_token = None
    else:
        sutui_token = None
        model = payload.model or getattr(current_user, "preferred_model", None) or ""
        if not model or model == "openclaw":
            model = _pick_default_model()

    mcp_tools = await _fetch_mcp_tools(raw_token)
    review_drafts_only = bool(getattr(payload, "review_prompt_drafts_only", False))
    if review_drafts_only:
        mcp_tools = []
        logger.info(
            "[CHAT] review_prompt_drafts_only：已禁用 MCP；使用极简 system（见 app.log 历史：主对话 system 曾导致只输出闲聊而非 JSON）"
        )
    has_tools = bool(mcp_tools)
    if not has_tools:
        logger.info(
            "MCP tools empty (port 8001 may be down or unreachable), chat has no capabilities; "
            "user will see 'cannot generate image'. Check that MCP service is started (run_mcp.bat / start.bat)."
        )
    sutui_override_url: Optional[str] = None
    sutui_override_headers: Optional[Dict[str, str]] = None
    if edition == "online":
        resolve_model, cfg_pre, sutui_override_url, sutui_override_headers = _online_resolve_cfg_and_overrides(
            payload, raw_token
        )
    else:
        resolve_model = model
        cfg_pre = _resolve_config(resolve_model) if resolve_model else None

    if review_drafts_only:
        sys_prompt = _REVIEW_PROMPT_DRAFTS_SYSTEM
    else:
        sys_prompt = (
        "你是「龙虾」(Lobster)，用户的私人 AI 助手。\n"
        + (_ONLINE_SYS_PREFIX if edition == "online" else "")
        + "龙虾内置了「速推 MCP」能力：文生图、图生视频、语音合成、视频解析等，具体以 list_capabilities 返回为准。\n\n"
        + (
            "【绝对禁止 — 违反将导致严重错误】\n"
            "1. 禁止模拟/伪造工具调用结果。你没有能力直接生成图片、发布内容、操作浏览器。你只能通过调用工具来做这些事。\n"
            "2. 禁止编造 URL、asset_id、图片链接、发布结果。所有数据必须来自工具返回。\n"
            "3. 禁止在回复中假装已经完成了操作（如\"已为你生成\"\"已发布成功\"）而实际没有调用工具。\n"
            "4. 禁止用文字描述代替工具调用。说\"好的，我来发布\"然后不调用工具 = 严重错误。\n"
            "5. 当用户要求执行操作时，你必须在本轮回复中调用工具，不能只回复文字。\n\n"
            "【正确做法】\n"
            "- 用户问「你能做什么」「速推能力」「MCP 能力」「内置能力」等 → 必须先调用 list_capabilities，根据返回的 capabilities、other_mcp_tools 与 integrations_via_app（企微、WhatsApp、Messenger 等为应用内集成，非 MCP）一并如实回答；不要只总结 invoke_capability 能力而漏掉发布、素材与集成说明。\n"
            "- 用户问「速推有哪些模型」「生成模型列表」「model 列表」等 → 依据 system 中注入的「速推模型清单」只列展示名与 model_id，不写类型行、不写 invoke_capability 示例；紧凑排版、一次尽量多列；禁止贴封面图。\n"
            "- 用户要你做事 → 立即调用对应的工具函数，等工具返回真实结果后再回复用户。\n"
            "- 不确定该调哪个工具 → 先调用 list_capabilities 或 list_assets 查询，不要猜测。\n"
            "- 工具调用失败 → 如实告诉用户失败原因，不要编造成功结果。\n\n"
            "【工具使用指南】\n"
            "生成图片：invoke_capability(capability_id=\"image.generate\", payload={\"prompt\":\"...\", \"model\":\"fal-ai/flux-2/flash\"})\n"
            "  → 返回 task_id 后用 task.get_result(task_id) 取结果，结果中 saved_assets[0].asset_id 为素材ID；"
            "若 saved_assets[0].source_url 存在，回复里给用户看的图片/视频直链只用 source_url，勿用 result 里的 v3-tasks 链。\n"
            + _V3_TASKS_URL_USER_HINT
            + _TASK_GET_RESULT_SYS_HINT
            + "【图片 prompt 规则】与视频相同：用用户原话作 prompt（去掉指令性表述如「发布到某账号」等），不要改写、不要臆造内容；仅当用户明确说「让ai写词」「你写词」「帮我写提示词」时才由你撰写 prompt。\n"
            "生成视频：文生视频 invoke_capability(capability_id=\"video.generate\", payload={\"model\":\"st-ai/super-seed2\", \"prompt\":\"...\", \"duration\":5})\n"
                "  图生视频 同上但 payload 加 image_url（**须为静态图片** jpg/png/webp 等公开 URL；**禁止**把 .mp4/.mov 等**视频直链**（含 cdn-video…/v3-tasks/…）当垫图，否则上游常返回 **HTTP 422**；本地图先用 sutui.transfer_url 转存）\n"
            "  → 用户明确要求「Sora 2 / Sora2」时：payload.model 必须填速推真实 id："
            "文生 fal-ai/sora-2/text-to-video，图生 fal-ai/sora-2/image-to-video（VIP/Pro 路径见速推模型清单）；"
            "禁止编造任何非清单内的 model 字符串（如 pb-movie-* 等，上游会 400）。\n"
            "  → 返回 task_id 后必须调 task.get_result(task_id) 轮询，视频通常 30–120 秒完成。不同视频模型在 API 层参数可能不同，当前统一传 model/prompt/image_url/aspect_ratio/duration，上游按 model 转成对应接口。\n"
            "  → 用户可明确指定用哪个模型生成：如「用 Seedance」「用 super-seed2」「用 wan 图生视频」，payload 的 model 字段即所用模型（如 st-ai/super-seed2、wan/v2.6/image-to-video）；未指定时默认可用 st-ai/super-seed2。\n"
            "【视频 prompt 规则】默认用用户原话作 prompt：先去掉用户消息里的指令性表述（如「发布到某账号」「发到抖音」「生成后发到XX」等），剩余原话直接当 prompt，不要改写、不要根据图片臆造内容（例如用户图与风景无关时禁止写风景描述）。仅当用户明确说「让ai写词」「你写词」「帮我写提示词」时，才由你撰写 prompt；否则一律用用户原话（去掉指令部分后）作为 prompt。\n"
            "生成并发布：仅当用户要先**新合成**视频/图时，才 video.generate（或 image.generate）→ task.get_result → publish_content；若用户**只**要求把**已有**素材发到平台，**跳过生成**，直接 publish_content。\n"
            "【素材剪辑 — 唯一合法路径，禁止替代方案】\n"
            "- 用户要对「已有素材」加字/叠字、裁剪、改比例、静音、换音轨、静图转视频、抽帧：必须调用 "
            "invoke_capability(capability_id=\"media.edit\", payload={\"operation\":\"overlay_text\",\"asset_id\":\"素材ID\",\"text\":\"文案\",\"vertical_align\":\"top\",\"horizontal_align\":\"center\",\"font_size\":48,\"font_color\":\"white\",\"font_alpha\":1,\"box\":false,\"shadow_x\":0,\"shadow_y\":0})；overlay_text 可选字段见 mcp/capability_catalog.json 与 docs/素材剪辑-overlay_text参数.md（仅允许白名单字段，多传会报错）；"
            "operation 还可 trim、scale_pad、mute、mux_audio、image_to_video、extract_frame（参数见 list_capabilities）。\n"
            "- **禁止**用 image.generate 文生图「重新画一张带字的图」代替叠字；**禁止**建议用户用 Photoshop、美图、外部软件、或「等系统恢复」作为主要办法；"
            "若 media.edit 报错，必须向用户**逐字引用**工具返回的错误，并可提示管理员在日志中搜索 `[media_edit]`、`[MCP media.edit]`、`[media_edit_exec]`。\n"
            "当用户要求「发到某账号」「发布到抖音」等时，在 task.get_result 返回成功（含 saved_assets 或 result 中的 asset_id）后，立即调用 publish_content（优先传 account_id）；无需等用户再次确认或点击。\n"
            "【发布约束】\n"
            "- 用户明确要「发布」「发到某账号」且已提供 **素材 ID** 或上下文已是 **成品视频/图片**（用户没说「先生成再发」）：只准 list_publish_accounts（如需）后立刻 **publish_content**；**禁止**再调 video.generate / image.generate，也**禁止**把成品 **.mp4/.mov 视频 URL**（含 cdn-video…/v3-tasks/…）当作图生视频的 image_url。\n"
            "- 发布必须由你调用 publish_content 等工具完成，不得要求用户「点加号」「到发布页」「准备好后告诉我」等手动操作。\n"
            "- task.get_result 返回成功且用户要求发布时，必须**在同一轮**紧接着调用 publish_content（或先 list_publish_accounts 再 publish_content），禁止只回复「视频已生成，现在去发布」「让我检查某账号是否存在」等文字而不调用工具；若需确认账号，先调 list_publish_accounts，拿到结果后立即调 publish_content。\n"
            "- **小红书**发布：调用 publish_content 时必须带 **title**，且 **description** 或 **tags** 至少一项（成品文案或话题）。**禁止**在用户未给任何文案要点时调用小红书发布。"
            "当用户用自然语言表示要「AI 写/帮我写文案/生成简介」等时，由你**自动**在工具里打开 AI 代写（具体字段见工具 schema），并把用户口述的要点、风格写入 **description**；**对用户只用人话**，禁止出现「请设置某某=true」或英文参数字段名。\n"
            "- **抖音、今日头条**等：用户未提供标题与正文时，可省略，由后端按会话模型 **AI 补全**；用户已写好则直接填入。用户明确不要 AI 时，你在工具内关闭 AI 代写（见 schema），对用户勿提技术字段名。\n"
            "- 用户说「用某素材生成视频并发布到某账号」时：发布时 asset_id 必须用 task.get_result 返回的 saved_assets 中的 ID（本次生成的视频），不得用用户提供的垫图/输入素材 ID。\n"
            "- 用户说「用生成的」「发刚才生成的」「用这个生成的素材」时：即指上一轮 task.get_result 已返回结果中的 saved_assets[0].asset_id，直接调用 publish_content(该 asset_id, account_id=…)，不要再次调用 video.generate 或 task.get_result。\n"
            "- 若 invoke_capability 或 task.get_result 返回错误/失败，必须明确告知用户「本次生成失败」及原因，不得用其他素材或历史结果冒充本次生成成功；只有当前 task.get_result 明确返回成功且含 saved_assets 时，才可回复「视频已生成」并继续发布。失败后禁止自行重试或再生成一个别的视频，只把失败原因提示给用户即可。\n"
            "发布：publish_content(asset_id, account_id 或 account_nickname, ...)；多平台同时发须用 list_publish_accounts 返回的 account_id。\n"
            "打开浏览器：open_account_browser(account_nickname=\"xxx\")\n"
            "检查登录：check_account_login(account_nickname=\"xxx\")\n"
            "查素材：list_assets  查账号：list_publish_accounts\n"
            "创作者发布数据（抖音/小红书/今日头条）：get_creator_publish_data(scope=all|platform|account) 读本地已同步快照；"
            "用户要最新数据时 sync_creator_publish_data(sync_all=true) 可一键同步全部可同步账号，或指定 platform / account_nickname。\n"
            "YouTube：publish_youtube_video(asset_id, youtube_account_id)；账号 ID 先 list_youtube_accounts；可选 material_origin=ai_generated（AI 成片）或 script_batch（脚本批量，默认）；默认 public。禁止用 publish_content 发 YouTube。\n"
            if has_tools
            else _no_tools_sys_hint(edition)
        )
        + "回答使用中文，简洁友好。"
        + " 当用户发送新的短消息（如问候、新问题）时，请直接针对该新消息简短回复，不要重复或延续上一条长回复的内容。"
    )

    if not review_drafts_only:
        sys_prompt = await _maybe_append_capabilities_snapshot_to_system(
            sys_prompt, (payload.message or "").strip(), raw_token, request, has_tools
        )
        sys_prompt = await _maybe_append_sutui_models_snapshot_to_system(
            sys_prompt, (payload.message or "").strip(), raw_token, request, has_tools
        )

    messages: List[Dict[str, str]] = [{"role": "system", "content": sys_prompt}]
    for m in (payload.history or []):
        if m.role in ("user", "assistant") and (m.content or "").strip():
            content = m.content.strip()
            if len(content) > MAX_HISTORY_MESSAGE_CHARS:
                content = (
                    content[: MAX_HISTORY_MESSAGE_CHARS // 2].rstrip()
                    + "\n\n...(上条内容已省略，请根据用户新消息直接回复。)"
                )
            messages.append({"role": m.role, "content": content})
    if len(messages) > MAX_HISTORY + 1:
        messages = [messages[0]] + messages[-MAX_HISTORY:]
    messages.append({"role": "user", "content": _build_user_content_with_attachments(payload, request, db=db, user_id=current_user.id)})

    t0 = time.perf_counter()

    # ── Primary path: direct LLM API with MCP tools ──
    attachment_urls = _get_attachment_public_urls(
        getattr(payload, "attachment_asset_ids", None), request, db, current_user.id
    )
    cfg = cfg_pre
    if cfg:
        _mcp_hdrs: Dict[str, str] = {}
        _prov = (cfg.get("provider") or "").strip()
        _mn = (cfg.get("model_name") or "").strip()
        if _prov and _mn:
            _mcp_hdrs["X-Chat-Model"] = f"{_prov}/{_mn}"
        _vurls_tok = _recent_task_video_urls_ctx.set([])
        _hints_tok = _generation_hints_by_task_id.set({})
        _mcp_var_tok = _mcp_forward_headers_ctx.set(_mcp_hdrs)
        try:
            logger.info("[对话] 请求 model=%s tools=%d", model, len(mcp_tools))
            if cfg["provider"] == "anthropic":
                reply = await _chat_anthropic(
                    messages,
                    cfg,
                    mcp_tools,
                    raw_token,
                    sutui_token=sutui_token,
                    attachment_urls=attachment_urls,
                    request=request,
                    db=db,
                    user_id=current_user.id,
                )
            else:
                reply = await _chat_openai(
                    messages,
                    cfg,
                    mcp_tools,
                    raw_token,
                    sutui_token=sutui_token,
                    attachment_urls=attachment_urls,
                    override_url=sutui_override_url,
                    override_headers=sutui_override_headers,
                    request=request,
                    db=db,
                    user_id=current_user.id,
                )

            ms = round((time.perf_counter() - t0) * 1000)
            _flush_tool_logs(db, current_user.id, payload.session_id, model)
            _log_turn(
                db, current_user.id, payload.message, _reply_for_user(reply),
                payload.session_id, payload.context_id,
                {"model": model, "mode": "direct", "duration_ms": ms, "tools": len(mcp_tools)},
            )
            db.commit()
            return JSONResponse(
                content=ChatResponse(reply=_reply_for_user(reply)).model_dump(),
                headers={"X-Duration-Ms": str(ms)},
            )
        except HTTPException:
            raise
        except Exception as e:
            logger.exception("Direct LLM call failed, trying OpenClaw fallback: %s", e)
        finally:
            _mcp_forward_headers_ctx.reset(_mcp_var_tok)
            _recent_task_video_urls_ctx.reset(_vurls_tok)
            _generation_hints_by_task_id.reset(_hints_tok)

    # ── Fallback: OpenClaw Gateway (no MCP tools)，使用真实模型 ID 以匹配 openclaw agents ──
    oc_model = resolve_model if resolve_model else _openclaw_fallback_model()
    oc_reply = await _try_openclaw(messages, oc_model, raw_token)
    if oc_reply:
        ms = round((time.perf_counter() - t0) * 1000)
        _flush_tool_logs(db, current_user.id, payload.session_id, model)
        _log_turn(
            db, current_user.id, payload.message, _reply_for_user(oc_reply),
            payload.session_id, payload.context_id,
            {"model": model, "mode": "openclaw", "duration_ms": ms},
        )
        db.commit()
        return JSONResponse(
            content=ChatResponse(reply=_reply_for_user(oc_reply)).model_dump(),
            headers={"X-Duration-Ms": str(ms)},
        )

    # ── No LLM path available ──
    if not cfg:
        detail = (
            f"模型 {model} 的 API Key 未配置。"
            "请在「系统配置」中添加对应的 API Key。"
        )
    else:
        detail = "LLM 服务暂时不可用，请稍后重试。"
    raise HTTPException(status_code=503, detail=detail)


# ── Stream endpoint (SSE progress) ─────────────────────────────────

async def _chat_stream_events(
    payload: ChatRequest,
    raw_token: str,
    current_user: Union[User, _ServerUser],
    db: Session,
    request: Optional[Request] = None,
):
    """Async generator: yield SSE events (progress + done). Runs chat with progress_cb pushing to queue."""
    queue: asyncio.Queue = asyncio.Queue()
    reply_holder: List[str] = []
    error_holder: List[str] = []
    _request_for_assets = request

    async def progress_cb(ev: Dict) -> None:
        await queue.put(ev)

    async def run_chat() -> None:
        _pending_tool_logs.set([])
        edition = (getattr(settings, "lobster_edition", None) or "online").strip().lower()
        if edition == "online":
            model = "sutui"
            sutui_token = None
        else:
            sutui_token = None
            model = payload.model or getattr(current_user, "preferred_model", None) or ""
            if not model or model == "openclaw":
                model = _pick_default_model()
        mcp_tools = await _fetch_mcp_tools(raw_token)
        has_tools = bool(mcp_tools)
        if not has_tools:
            logger.info("MCP tools empty (stream path), chat has no capabilities")
        sutui_override_url: Optional[str] = None
        sutui_override_headers: Optional[Dict[str, str]] = None
        if edition == "online":
            resolve_model, cfg_pre, sutui_override_url, sutui_override_headers = _online_resolve_cfg_and_overrides(
                payload, raw_token
            )
        else:
            resolve_model = model
            cfg_pre = _resolve_config(resolve_model) if resolve_model else None
        sys_prompt = (
            "你是「龙虾」(Lobster)，用户的私人 AI 助手。\n"
            + (_ONLINE_SYS_PREFIX if edition == "online" else "")
            + "龙虾内置了「速推 MCP」能力：文生图、图生视频、语音合成、视频解析等，具体以 list_capabilities 返回为准。\n\n"
            + (
                "【绝对禁止 — 违反将导致严重错误】\n"
                "1. 禁止模拟/伪造工具调用结果。你没有能力直接生成图片、发布内容、操作浏览器。你只能通过调用工具来做这些事。\n"
                "2. 禁止编造 URL、asset_id、图片链接、发布结果。所有数据必须来自工具返回。\n"
                "3. 禁止在回复中假装已经完成了操作（如\"已为你生成\"\"已发布成功\"）而实际没有调用工具。\n"
                "4. 禁止用文字描述代替工具调用。说\"好的，我来发布\"然后不调用工具 = 严重错误。\n"
                "5. 当用户要求执行操作时，你必须在本轮回复中调用工具，不能只回复文字。\n\n"
                "【正确做法】\n"
                "- 用户问「你能做什么」「速推能力」「MCP 能力」「内置能力」等 → 必须先调用 list_capabilities，根据返回的 capabilities、other_mcp_tools 与 integrations_via_app（企微、WhatsApp、Messenger 等为应用内集成，非 MCP）一并如实回答；不要只总结 invoke_capability 能力而漏掉发布、素材与集成说明。\n"
                "- 用户问「速推有哪些模型」「生成模型列表」「model 列表」等 → 依据 system 中注入的「速推模型清单」只列展示名与 model_id，不写类型行、不写 invoke_capability 示例；紧凑排版、一次尽量多列；禁止贴封面图。\n"
                "- 用户要你做事 → 立即调用对应的工具函数，等工具返回真实结果后再回复用户。\n"
                "- 不确定该调哪个工具 → 先调用 list_capabilities 或 list_assets 查询，不要猜测。\n"
                "- 工具调用失败 → 如实告诉用户失败原因，不要编造成功结果。\n\n"
                "【工具使用指南】\n"
                "生成图片：invoke_capability(capability_id=\"image.generate\", payload={\"prompt\":\"...\", \"model\":\"fal-ai/flux-2/flash\"})\n"
                "  → 返回 task_id 后用 task.get_result(task_id) 取结果，结果中 saved_assets[0].asset_id 为素材ID\n"
                + _V3_TASKS_URL_USER_HINT
                + _TASK_GET_RESULT_SYS_HINT
                + "【图片 prompt 规则】与视频相同：用用户原话作 prompt（去掉指令性表述如「发布到某账号」等），不要改写、不要臆造内容；仅当用户明确说「让ai写词」「你写词」「帮我写提示词」时才由你撰写 prompt。\n"
                "生成视频：文生视频 invoke_capability(capability_id=\"video.generate\", payload={\"model\":\"st-ai/super-seed2\", \"prompt\":\"...\", \"duration\":5})\n"
                "  图生视频 同上但 payload 加 image_url（**须为静态图片** jpg/png/webp 等公开 URL；**禁止**把 .mp4/.mov 等**视频直链**（含 cdn-video…/v3-tasks/…）当垫图，否则上游常返回 **HTTP 422**；本地图先用 sutui.transfer_url 转存）\n"
                "  → 用户明确要求「Sora 2 / Sora2」时：payload.model 必须填速推真实 id："
                "文生 fal-ai/sora-2/text-to-video，图生 fal-ai/sora-2/image-to-video（VIP/Pro 路径见速推模型清单）；"
                "禁止编造任何非清单内的 model 字符串（如 pb-movie-* 等，上游会 400）。\n"
                "  → 返回 task_id 后必须调 task.get_result(task_id) 轮询，视频通常 30–120 秒完成。不同视频模型在 API 层参数可能不同，当前统一传 model/prompt/image_url/aspect_ratio/duration，上游按 model 转成对应接口。\n"
                "  → 用户可明确指定用哪个模型生成：如「用 Seedance」「用 super-seed2」「用 wan 图生视频」，payload 的 model 字段即所用模型（如 st-ai/super-seed2、wan/v2.6/image-to-video）；未指定时默认可用 st-ai/super-seed2。\n"
                "【视频 prompt 规则】默认用用户原话作 prompt：先去掉用户消息里的指令性表述（如「发布到某账号」「发到抖音」「生成后发到XX」等），剩余原话直接当 prompt，不要改写、不要根据图片臆造内容（例如用户图与风景无关时禁止写风景描述）。仅当用户明确说「让ai写词」「你写词」「帮我写提示词」时，才由你撰写 prompt；否则一律用用户原话（去掉指令部分后）作为 prompt。\n"
            "生成并发布：仅当用户要先**新合成**视频/图时，才 video.generate（或 image.generate）→ task.get_result → publish_content；若用户**只**要求把**已有**素材发到平台，**跳过生成**，直接 publish_content。\n"
            "【素材剪辑 — 唯一合法路径，禁止替代方案】\n"
            "- 用户要对「已有素材」加字/叠字、裁剪、改比例、静音、换音轨、静图转视频、抽帧：必须调用 "
            "invoke_capability(capability_id=\"media.edit\", payload={\"operation\":\"overlay_text\",\"asset_id\":\"素材ID\",\"text\":\"文案\",\"vertical_align\":\"top\",\"horizontal_align\":\"center\",\"font_size\":48,\"font_color\":\"white\",\"font_alpha\":1,\"box\":false,\"shadow_x\":0,\"shadow_y\":0})；overlay_text 可选字段见 mcp/capability_catalog.json 与 docs/素材剪辑-overlay_text参数.md（仅允许白名单字段，多传会报错）；"
            "operation 还可 trim、scale_pad、mute、mux_audio、image_to_video、extract_frame（参数见 list_capabilities）。\n"
            "- **禁止**用 image.generate 文生图「重新画一张带字的图」代替叠字；**禁止**建议用户用 Photoshop、美图、外部软件、或「等系统恢复」作为主要办法；"
            "若 media.edit 报错，必须向用户**逐字引用**工具返回的错误，并可提示管理员在日志中搜索 `[media_edit]`、`[MCP media.edit]`、`[media_edit_exec]`。\n"
            "当用户要求「发到某账号」「发布到抖音」等时，在 task.get_result 返回成功（含 saved_assets 或 result 中的 asset_id）后，立即调用 publish_content（优先传 account_id）；无需等用户再次确认或点击。\n"
            "【发布约束】\n"
            "- 用户明确要「发布」「发到某账号」且已提供 **素材 ID** 或上下文已是 **成品视频/图片**（用户没说「先生成再发」）：只准 list_publish_accounts（如需）后立刻 **publish_content**；**禁止**再调 video.generate / image.generate，也**禁止**把成品 **.mp4/.mov 视频 URL**（含 cdn-video…/v3-tasks/…）当作图生视频的 image_url。\n"
            "- 发布必须由你调用 publish_content 等工具完成，不得要求用户「点加号」「到发布页」「准备好后告诉我」等手动操作。\n"
            "- task.get_result 返回成功且用户要求发布时，必须**在同一轮**紧接着调用 publish_content（或先 list_publish_accounts 再 publish_content），禁止只回复「视频已生成，现在去发布」「让我检查某账号是否存在」等文字而不调用工具；若需确认账号，先调 list_publish_accounts，拿到结果后立即调 publish_content。\n"
            "- **小红书**发布：调用 publish_content 时必须带 **title**，且 **description** 或 **tags** 至少一项（成品文案或话题）。**禁止**在用户未给任何文案要点时调用小红书发布。"
            "当用户用自然语言表示要「AI 写/帮我写文案/生成简介」等时，由你**自动**在工具里打开 AI 代写（具体字段见工具 schema），并把用户口述的要点、风格写入 **description**；**对用户只用人话**，禁止出现「请设置某某=true」或英文参数字段名。\n"
            "- **抖音、今日头条**等：用户未提供标题与正文时，可省略，由后端按会话模型 **AI 补全**；用户已写好则直接填入。用户明确不要 AI 时，你在工具内关闭 AI 代写（见 schema），对用户勿提技术字段名。\n"
            "- 用户说「用某素材生成视频并发布到某账号」时：发布时 asset_id 必须用 task.get_result 返回的 saved_assets 中的 ID（本次生成的视频），不得用用户提供的垫图/输入素材 ID。\n"
            "- 用户说「用生成的」「发刚才生成的」「用这个生成的素材」时：即指上一轮 task.get_result 已返回结果中的 saved_assets[0].asset_id，直接调用 publish_content(该 asset_id, account_id=…)，不要再次调用 video.generate 或 task.get_result。\n"
            "- 若 invoke_capability 或 task.get_result 返回错误/失败，必须明确告知用户「本次生成失败」及原因，不得用其他素材或历史结果冒充本次生成成功；只有当前 task.get_result 明确返回成功且含 saved_assets 时，才可回复「视频已生成」并继续发布。失败后禁止自行重试或再生成一个别的视频，只把失败原因提示给用户即可。\n"
            "发布：publish_content(asset_id, account_id 或 account_nickname, ...)；多平台同时发须用 list_publish_accounts 返回的 account_id。\n"
            "打开浏览器：open_account_browser(account_nickname=\"xxx\")\n"
            "检查登录：check_account_login(account_nickname=\"xxx\")\n"
            "查素材：list_assets  查账号：list_publish_accounts\n"
            "创作者发布数据（抖音/小红书/今日头条）：get_creator_publish_data(scope=all|platform|account) 读本地已同步快照；"
            "用户要最新数据时 sync_creator_publish_data(sync_all=true) 可一键同步全部可同步账号，或指定 platform / account_nickname。\n"
            "YouTube：publish_youtube_video(asset_id, youtube_account_id)；账号 ID 先 list_youtube_accounts；可选 material_origin=ai_generated（AI 成片）或 script_batch（脚本批量，默认）；默认 public。禁止用 publish_content 发 YouTube。\n"
            if has_tools
            else _no_tools_sys_hint(edition)
        )
        + "回答使用中文，简洁友好。"
        + " 当用户发送新的短消息（如问候、新问题）时，请直接针对该新消息简短回复，不要重复或延续上一条长回复的内容。"
        )
        sys_prompt = await _maybe_append_capabilities_snapshot_to_system(
            sys_prompt, (payload.message or "").strip(), raw_token, request, has_tools
        )
        sys_prompt = await _maybe_append_sutui_models_snapshot_to_system(
            sys_prompt, (payload.message or "").strip(), raw_token, request, has_tools
        )
        messages = [{"role": "system", "content": sys_prompt}]
        for m in (payload.history or []):
            if m.role in ("user", "assistant") and (m.content or "").strip():
                content = m.content.strip()
                if len(content) > MAX_HISTORY_MESSAGE_CHARS:
                    content = (
                        content[: MAX_HISTORY_MESSAGE_CHARS // 2].rstrip()
                        + "\n\n...(上条内容已省略，请根据用户新消息直接回复。)"
                    )
                messages.append({"role": m.role, "content": content})
        if len(messages) > MAX_HISTORY + 1:
            messages = [messages[0]] + messages[-MAX_HISTORY:]
        stream_attachment_urls: List[str] = []
        try:
            messages.append(
                {
                    "role": "user",
                    "content": _build_user_content_with_attachments(
                        payload, _request_for_assets, db=db, user_id=current_user.id
                    ),
                }
            )
            stream_attachment_urls = _get_attachment_public_urls(
                getattr(payload, "attachment_asset_ids", None),
                _request_for_assets,
                db,
                current_user.id,
            )
        except HTTPException as e:
            det = e.detail
            error_holder.append(det if isinstance(det, str) else str(det))
        if not error_holder:
            cfg = cfg_pre
            try:
                if cfg:
                    _mcp_sh: Dict[str, str] = {}
                    _sp = (cfg.get("provider") or "").strip()
                    _sm = (cfg.get("model_name") or "").strip()
                    if _sp and _sm:
                        _mcp_sh["X-Chat-Model"] = f"{_sp}/{_sm}"
                    _vurls_stream_tok = _recent_task_video_urls_ctx.set([])
                    _hints_stream_tok = _generation_hints_by_task_id.set({})
                    _mcp_stream_tok = _mcp_forward_headers_ctx.set(_mcp_sh)
                    try:
                        if cfg["provider"] == "anthropic":
                            reply = await _chat_anthropic(
                                messages, cfg, mcp_tools, raw_token,
                                sutui_token=sutui_token,
                                progress_cb=progress_cb,
                                attachment_urls=stream_attachment_urls,
                                request=request,
                                db=db,
                                user_id=current_user.id,
                            )
                        else:
                            reply = await _chat_openai(
                                messages, cfg, mcp_tools, raw_token,
                                sutui_token=sutui_token,
                                progress_cb=progress_cb,
                                attachment_urls=stream_attachment_urls,
                                override_url=sutui_override_url,
                                override_headers=sutui_override_headers,
                                request=request,
                                db=db,
                                user_id=current_user.id,
                            )
                        reply_holder.append(reply)
                        _flush_tool_logs(db, current_user.id, payload.session_id, model)
                        _log_turn(
                            db, current_user.id, payload.message, _reply_for_user(reply),
                            payload.session_id, payload.context_id,
                            {"model": model, "mode": "direct", "tools": len(mcp_tools)},
                        )
                        db.commit()
                    finally:
                        _mcp_forward_headers_ctx.reset(_mcp_stream_tok)
                        _recent_task_video_urls_ctx.reset(_vurls_stream_tok)
                        _generation_hints_by_task_id.reset(_hints_stream_tok)
                else:
                    oc_model = resolve_model if resolve_model else _openclaw_fallback_model()
                    oc_reply = await _try_openclaw(messages, oc_model, raw_token)
                    if oc_reply:
                        reply_holder.append(oc_reply)
                        _flush_tool_logs(db, current_user.id, payload.session_id, model)
                        _log_turn(
                            db, current_user.id, payload.message, _reply_for_user(oc_reply),
                            payload.session_id, payload.context_id,
                            {"model": model, "mode": "openclaw"},
                        )
                        db.commit()
                    else:
                        error_holder.append("LLM 服务暂时不可用")
            except HTTPException as e:
                error_holder.append(e.detail if isinstance(e.detail, str) else str(e.detail))
            except Exception as e:
                logger.exception("chat/stream run_chat error")
                error_holder.append(str(e))
        final_reply = reply_holder[0] if reply_holder else ""
        final_error = error_holder[0] if error_holder else None
        if final_error:
            final_reply = f"错误：{final_error}"
        else:
            final_reply = _reply_for_user(final_reply)
        await queue.put({"type": "done", "reply": final_reply, "error": final_error})

    task = asyncio.create_task(run_chat())
    try:
        while True:
            if request is not None and await request.is_disconnected():
                break
            try:
                ev = await asyncio.wait_for(queue.get(), timeout=30.0)
            except asyncio.TimeoutError:
                if request is not None and await request.is_disconnected():
                    break
                yield f"data: {json.dumps({'type': 'heartbeat'}, ensure_ascii=False)}\n\n"
                continue
            yield f"data: {json.dumps(ev, ensure_ascii=False)}\n\n"
            if ev.get("type") == "done":
                break
    finally:
        if not task.done():
            task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass


@router.post("/chat/stream", summary="智能对话（流式返回思考/工具进度）")
async def chat_stream_endpoint(
    request: Request,
    payload: ChatRequest,
    raw_token: str = Depends(oauth2_scheme),
    current_user: Union[User, _ServerUser] = Depends(get_current_user_for_chat),
    db: Session = Depends(get_db),
):
    """Stream SSE events: tool_start, tool_end, then done with reply. Frontend can show progress in chat."""
    return StreamingResponse(
        _chat_stream_events(payload, raw_token, current_user, db, request),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


# ── Chat history ──────────────────────────────────────────────────

@router.get("/chat/history", summary="会话历史")
def list_chat_history(
    context_id: Optional[str] = None,
    limit: int = 100,
    offset: int = 0,
    current_user: Union[User, _ServerUser] = Depends(get_current_user_for_chat),
    db: Session = Depends(get_db),
):
    q = db.query(ChatTurnLog).filter(ChatTurnLog.user_id == current_user.id)
    if context_id:
        q = q.filter(ChatTurnLog.context_id == context_id)
    rows = (
        q.order_by(ChatTurnLog.created_at.desc())
        .offset(max(offset, 0))
        .limit(min(max(limit, 1), 500))
        .all()
    )
    return [
        {
            "id": r.id,
            "session_id": r.session_id,
            "context_id": r.context_id,
            "user_message": r.user_message,
            "assistant_reply": r.assistant_reply,
            "meta": r.meta,
            "created_at": r.created_at.isoformat() if r.created_at else "",
        }
        for r in rows
    ]


# ── Tool call logs (生产记录) ─────────────────────────────────────

@router.get("/api/tool-logs", summary="MCP 工具调用记录")
def list_tool_logs(
    tool_name: Optional[str] = None,
    success_only: bool = False,
    limit: int = 50,
    offset: int = 0,
    current_user: Union[User, _ServerUser] = Depends(get_current_user_for_chat),
    db: Session = Depends(get_db),
):
    q = db.query(ToolCallLog).filter(ToolCallLog.user_id == current_user.id)
    if tool_name:
        q = q.filter(ToolCallLog.tool_name == tool_name)
    if success_only:
        q = q.filter(ToolCallLog.success.is_(True))
    total = q.count()
    rows = (
        q.order_by(ToolCallLog.created_at.desc())
        .offset(max(offset, 0))
        .limit(min(max(limit, 1), 200))
        .all()
    )
    return {
        "total": total,
        "items": [
            {
                "id": r.id,
                "tool_name": r.tool_name,
                "arguments": r.arguments,
                "result_text": r.result_text[:2000] if r.result_text else None,
                "result_urls": r.result_urls.split(",") if r.result_urls else [],
                "success": r.success,
                "latency_ms": r.latency_ms,
                "session_id": r.session_id,
                "model": r.model,
                "created_at": r.created_at.isoformat() if r.created_at else "",
            }
            for r in rows
        ],
    }


@router.get("/api/tool-logs/stats", summary="工具调用统计")
def tool_log_stats(
    current_user: Union[User, _ServerUser] = Depends(get_current_user_for_chat),
    db: Session = Depends(get_db),
):
    from sqlalchemy import Integer as SaInt, func
    rows = (
        db.query(
            ToolCallLog.tool_name,
            func.count(ToolCallLog.id).label("count"),
            func.sum(ToolCallLog.success.is_(True).cast(SaInt)).label("success_count"),
        )
        .filter(ToolCallLog.user_id == current_user.id)
        .group_by(ToolCallLog.tool_name)
        .all()
    )
    return [
        {"tool_name": r.tool_name, "count": r.count, "success_count": r.success_count or 0}
        for r in rows
    ]


# ── 生产记录：仅速推能力调用 + 模型对话，无重复 ─────────────────────────────

def _production_records_merged(
    current_user: Union[User, _ServerUser],
    db: Session,
    limit: int = 50,
    offset: int = 0,
):
    """合并 CapabilityCallLog（速推生成）与 ChatTurnLog（模型调用），按时间倒序，无重复。"""
    cap_rows = (
        db.query(CapabilityCallLog)
        .filter(CapabilityCallLog.user_id == current_user.id)
        .order_by(CapabilityCallLog.created_at.desc())
        .limit(150)
        .all()
    )
    turn_rows = (
        db.query(ChatTurnLog)
        .filter(ChatTurnLog.user_id == current_user.id)
        .order_by(ChatTurnLog.created_at.desc())
        .limit(150)
        .all()
    )
    merged = []
    for r in cap_rows:
        merged.append({
            "type": "capability",
            "id": f"c{r.id}",
            "created_at": r.created_at.isoformat() if r.created_at else "",
            "capability_id": r.capability_id,
            "success": r.success,
            "latency_ms": r.latency_ms,
            "error_message": (r.error_message or "")[:500] if r.error_message else None,
            "status": r.status,
        })
    for r in turn_rows:
        merged.append({
            "type": "model",
            "id": f"t{r.id}",
            "created_at": r.created_at.isoformat() if r.created_at else "",
            "user_message": (r.user_message or "")[:300],
            "assistant_reply": (r.assistant_reply or "")[:500],
        })
    merged.sort(key=lambda x: x["created_at"], reverse=True)
    total = len(merged)
    page = merged[offset : offset + limit]
    return {"total": total, "items": page}


@router.get("/api/production/records", summary="生产记录（仅速推能力+模型对话）")
def list_production_records(
    limit: int = 50,
    offset: int = 0,
    current_user: Union[User, _ServerUser] = Depends(get_current_user_for_chat),
    db: Session = Depends(get_db),
):
    """仅返回：速推能力调用（CapabilityCallLog）、模型对话轮次（ChatTurnLog）。可刷新看进度，无重复。"""
    return _production_records_merged(current_user=current_user, db=db, limit=min(max(limit, 1), 100), offset=max(offset, 0))


@router.post("/api/production/refresh-pending", summary="刷新待处理（兼容）")
def production_refresh_pending(current_user: Union[User, _ServerUser] = Depends(get_current_user_for_chat)):
    """兼容旧前端，无实际操作，返回成功。"""
    return {"ok": True}
